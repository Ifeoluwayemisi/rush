"use client";

/**
 * PinPadModal — reusable 4-digit transaction PIN entry sheet.
 *
 * Modern-fintech style PIN pad (OPay / Moniepoint / Cash App feel):
 *  - Dot mask instead of a visible text input
 *  - Large tappable keypad (works on touch + mouse + physical keyboard)
 *  - Auto-submits on the 4th digit in verify mode
 *  - Shake + red dots on a wrong PIN, with attempts-remaining counter
 *  - Server-driven lockout: shows a live mm:ss countdown and refuses
 *    input until the lock expires (PIN_LOCKED + retryAfterSeconds)
 *  - "set" mode: enter + confirm a new PIN with weak-PIN checks
 *    mirrored from the server policy; after creation it flips back
 *    to verify so the user confirms the PIN to finish the pending
 *    transaction (setup-then-continue flow)
 *
 * Usage:
 *   const [pinOpen, setPinOpen] = useState(false);
 *   const [pinMode, setPinMode] = useState<"verify" | "set">("verify");
 *   <PinPadModal
 *     open={pinOpen} onOpenChange={setPinOpen}
 *     mode={pinMode} onModeChange={setPinMode}
 *     title="Confirm withdrawal" subtitle="Enter your PIN to withdraw ₦5,000"
 *     onSubmitPin={async (pin) => { await api.post("/api/wallet/withdraw", { amount, pin }); }}
 *   />
 *
 * When a guarded API returns code "PIN_SETUP_REQUIRED", flip the mode
 * to "set" — the modal walks the user through creation and returns to
 * verify mode so the original action can complete with the new PIN.
 *
 * Implementation note: the pad body is mounted with `key={mode}` and
 * only while `open` — React discards its entire state on close and on
 * mode flips, so no reset effects are needed.
 */

import { useCallback, useEffect, useState } from "react";
import { Delete, Loader2, Lock, ShieldCheck, ShieldAlert } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { api, ApiError } from "@/lib/api-client";
import {
  PIN_LENGTH,
  validateNewPin,
  sanitizePin,
  PIN_ERROR_CODES,
} from "@/lib/pin-policy";

export type PinPadMode = "verify" | "set";

interface PinPadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: PinPadMode;
  /** Fired when the modal internally flips between set → verify. */
  onModeChange?: (mode: PinPadMode) => void;
  title: string;
  subtitle?: string;
  /** verify mode — throw (e.g. ApiError) to display the error. */
  onSubmitPin: (pin: string) => Promise<void>;
  /** set mode — fired after the PIN was created successfully. */
  onPinSet?: () => void;
}

function mmss(total: number): string {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

/**
 * Ticking clock — only re-renders once per second while active.
 * setState happens inside the interval callback (an external-system
 * subscription), never synchronously in the effect body.
 */
function useNow(active: boolean): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [active]);
  return now;
}

// ─── The pad body (stateful, remounts per session) ─────────────────────

interface PinPadBodyProps {
  mode: PinPadMode;
  onModeChange?: (mode: PinPadMode) => void;
  title: string;
  subtitle?: string;
  onSubmitPin: (pin: string) => Promise<void>;
  onPinSet?: () => void;
  onClose: () => void;
}

function PinPadBody({
  mode,
  onModeChange,
  title,
  subtitle,
  onSubmitPin,
  onPinSet,
  onClose,
}: PinPadBodyProps) {
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [setStep, setSetStep] = useState<1 | 2>(1); // set mode: 1 = choose, 2 = confirm
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [lockUntil, setLockUntil] = useState<number | null>(null);

  const now = useNow(lockUntil !== null);
  const secondsLeft =
    lockUntil !== null ? Math.max(0, Math.ceil((lockUntil - now) / 1000)) : 0;
  const locked = secondsLeft > 0;

  // Auto-close shortly after a live lock expires so the countdown
  // doesn't linger on a dead sheet.
  useEffect(() => {
    if (lockUntil !== null && secondsLeft === 0) {
      const id = window.setTimeout(() => onClose(), 1500);
      return () => window.clearTimeout(id);
    }
  }, [lockUntil, secondsLeft, onClose]);

  const fail = useCallback(
    (msg: string) => {
      setError(msg);
      setShake(true);
      setPin("");
      setConfirmPin("");
      if (mode === "set") setSetStep(1);
      window.setTimeout(() => setShake(false), 500);
    },
    [mode],
  );

  // ─── verify mode: submit a complete PIN ─────────────────────────────
  const runVerify = useCallback(
    async (entered: string) => {
      setBusy(true);
      setError(null);
      try {
        await onSubmitPin(entered);
        // Success — parent closes the sheet (or navigates).
        setPin("");
      } catch (e) {
        if (e instanceof ApiError) {
          if (e.code === PIN_ERROR_CODES.LOCKED) {
            const s = Number(e.meta?.retryAfterSeconds) || 900;
            setLockUntil(Date.now() + s * 1000);
            fail(e.message);
          } else if (e.code === PIN_ERROR_CODES.SETUP_REQUIRED) {
            // Parent flips mode to "set" via onModeChange.
            setNotice(e.message);
            onModeChange?.("set");
          } else {
            fail(e.message);
          }
        } else {
          fail(e instanceof Error ? e.message : "Something went wrong. Try again.");
        }
      } finally {
        setBusy(false);
      }
    },
    [onSubmitPin, fail, onModeChange],
  );

  // ─── set mode: create the PIN via the API ───────────────────────────
  const runSet = useCallback(
    async (chosen: string) => {
      setBusy(true);
      setError(null);
      try {
        await api.post("/api/auth/set-pin", { pin: chosen });
        setNotice("PIN created — confirm it to continue.");
        setPin("");
        setConfirmPin("");
        setSetStep(1);
        onPinSet?.();
        onModeChange?.("verify");
      } catch (e) {
        if (e instanceof ApiError && e.code === PIN_ERROR_CODES.WEAK) {
          fail(e.message);
        } else if (
          e instanceof ApiError &&
          e.code === PIN_ERROR_CODES.CURRENT_PIN_REQUIRED
        ) {
          fail("You already have a PIN. Change it from Profile → Security instead.");
        } else if (e instanceof ApiError && e.code === PIN_ERROR_CODES.LOCKED) {
          const s = Number(e.meta?.retryAfterSeconds) || 900;
          setLockUntil(Date.now() + s * 1000);
          fail(e.message);
        } else {
          fail(e instanceof Error ? e.message : "Couldn't set your PIN. Try again.");
        }
      } finally {
        setBusy(false);
      }
    },
    [fail, onPinSet, onModeChange],
  );

  // ─── Keypad input ────────────────────────────────────────────────────
  const press = useCallback(
    (digit: string) => {
      if (busy || locked) return;
      setError(null);
      if (mode === "verify") {
        const next = sanitizePin(pin + digit).slice(0, PIN_LENGTH);
        setPin(next);
        if (next.length === PIN_LENGTH) {
          void runVerify(next);
        }
      } else {
        if (setStep === 1) {
          const next = sanitizePin(pin + digit).slice(0, PIN_LENGTH);
          setPin(next);
          if (next.length === PIN_LENGTH) {
            // Client-side mirror of the server policy for instant feedback.
            const weak = validateNewPin(next);
            if (weak) {
              fail(weak);
              return;
            }
            setSetStep(2);
            setNotice("Re-enter the PIN to confirm.");
          }
        } else {
          const next = sanitizePin(confirmPin + digit).slice(0, PIN_LENGTH);
          setConfirmPin(next);
          if (next.length === PIN_LENGTH) {
            if (next !== pin) {
              fail("PINs don't match. Start again.");
              return;
            }
            void runSet(next);
          }
        }
      }
    },
    [busy, locked, mode, pin, confirmPin, setStep, runVerify, runSet, fail],
  );

  const backspace = useCallback(() => {
    if (busy || locked) return;
    setError(null);
    if (mode === "verify" || setStep === 1) {
      setPin((p) => p.slice(0, -1));
    } else {
      setConfirmPin((p) => p.slice(0, -1));
    }
  }, [busy, locked, mode, setStep]);

  // Physical keyboard support.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        press(e.key);
      } else if (e.key === "Backspace") {
        e.preventDefault();
        backspace();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [press, backspace]);

  const activeValue = mode === "verify" || setStep === 1 ? pin : confirmPin;

  const stepTitle =
    mode === "set"
      ? setStep === 1
        ? "Create your transaction PIN"
        : "Confirm your new PIN"
      : title;

  const stepSubtitle =
    mode === "set"
      ? setStep === 1
        ? "4 digits. You'll use it for withdrawals and wallet payments."
        : "Enter the same 4 digits again."
      : subtitle;

  return (
    <div className="mx-auto flex w-full max-w-sm flex-col items-center gap-4">
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-rush-soft/60">
        {locked ? (
          <ShieldAlert className="h-5 w-5 text-red-600" />
        ) : (
          <Lock className="h-5 w-5 text-rush-deep" />
        )}
      </div>

      <div className="text-center">
        <p className="text-base font-bold text-ink">{stepTitle}</p>
        {stepSubtitle && (
          <p className="mt-1 text-xs text-ink-soft">{stepSubtitle}</p>
        )}
      </div>

      {/* Dots */}
      <div className={`flex items-center gap-3 ${shake ? "pin-shake" : ""}`} aria-hidden>
        {Array.from({ length: PIN_LENGTH }).map((_, i) => (
          <span
            key={i}
            className={`h-3.5 w-3.5 rounded-full transition-colors ${
              i < activeValue.length ? (error ? "bg-red-500" : "bg-rush") : "bg-ink/15"
            }`}
          />
        ))}
      </div>

      {/* Status line */}
      <div className="h-8 text-center">
        {locked ? (
          <p className="text-xs font-semibold text-red-600">
            PIN locked — try again in {mmss(secondsLeft)}
          </p>
        ) : error ? (
          <p className="text-xs font-medium text-red-600">{error}</p>
        ) : notice ? (
          <p className="text-xs font-medium text-rush-deep">{notice}</p>
        ) : busy ? (
          <p className="flex items-center justify-center gap-1.5 text-xs text-ink-soft">
            <Loader2 className="h-3 w-3 animate-spin" /> Verifying…
          </p>
        ) : null}
      </div>

      {/* Keypad */}
      <div
        className={`grid w-full grid-cols-3 gap-2.5 ${
          locked || busy ? "pointer-events-none opacity-40" : ""
        }`}
      >
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => press(d)}
            className="h-[52px] rounded-xl bg-surface text-xl font-semibold text-ink transition-colors active:bg-rush-soft"
            disabled={locked || busy}
          >
            {d}
          </button>
        ))}
        <button
          type="button"
          onClick={() => {
            setPin("");
            setConfirmPin("");
            setSetStep(1);
            setError(null);
            setNotice(
              mode === "set" && setStep === 2 ? "Re-enter the PIN to confirm." : null,
            );
          }}
          className="h-[52px] rounded-xl text-[11px] font-semibold text-ink-soft transition-colors hover:bg-surface"
          disabled={locked || busy}
        >
          Clear
        </button>
        <button
          type="button"
          onClick={() => press("0")}
          className="h-[52px] rounded-xl bg-surface text-xl font-semibold text-ink transition-colors active:bg-rush-soft"
          disabled={locked || busy}
        >
          0
        </button>
        <button
          type="button"
          onClick={backspace}
          className="flex h-[52px] items-center justify-center rounded-xl text-ink-soft transition-colors hover:bg-surface"
          disabled={locked || busy}
          aria-label="Delete last digit"
        >
          <Delete className="h-5 w-5" />
        </button>
      </div>

      <p className="flex items-center gap-1.5 text-center text-[10px] text-ink-soft">
        <ShieldCheck className="h-3 w-3" />
        {mode === "set"
          ? "Never share your PIN — Rush staff will never ask for it."
          : "5 wrong attempts temporarily locks your PIN."}
      </p>
    </div>
  );
}

// ─── Outer sheet — remounts the body per session ────────────────────────

export function PinPadModal({
  open,
  onOpenChange,
  mode,
  onModeChange,
  title,
  subtitle,
  onSubmitPin,
  onPinSet,
}: PinPadModalProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="max-h-[92vh] rounded-t-2xl px-5 pb-8 pt-2"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <SheetHeader className="sr-only">
          <SheetTitle>{title}</SheetTitle>
        </SheetHeader>

        {open && (
          <PinPadBody
            // Remount per session AND on mode flips → fresh entry state
            // with zero reset effects.
            key={`${mode}`}
            mode={mode}
            onModeChange={onModeChange}
            title={title}
            subtitle={subtitle}
            onSubmitPin={onSubmitPin}
            onPinSet={onPinSet}
            onClose={() => onOpenChange(false)}
          />
        )}
      </SheetContent>
    </Sheet>
  );
}
