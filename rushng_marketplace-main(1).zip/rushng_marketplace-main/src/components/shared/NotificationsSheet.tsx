"use client";

import { useState, useEffect } from "react";
import {
  Loader2, Bell, BellOff, CheckCheck, Package, Car, Wallet as WalletIcon,
  ShieldCheck, ChevronRight,
} from "lucide-react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useRush } from "@/lib/store";
import { api } from "@/lib/api-client";
import { formatRelativeTime } from "@/lib/date-utils";

interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  read: boolean;
  createdAt: string;
  link: { view: string; params?: Record<string, string> } | null;
}

interface NotificationsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function NotificationsSheet({ open, onOpenChange }: NotificationsSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-2xl">
        <SheetHeader>
          <SheetTitle>Notifications</SheetTitle>
        </SheetHeader>
        {open && <NotifContent onDone={() => onOpenChange(false)} />}
      </SheetContent>
    </Sheet>
  );
}

function NotifContent({ onDone }: { onDone: () => void }) {
  const { navigate, pushToast } = useRush();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  async function loadNotifications() {
    setLoading(true);
    try {
      const r = await api.get<{ notifications: NotificationItem[] }>("/api/notifications");
      setNotifications(r.notifications || []);
    } catch {
      setNotifications([]);
    } finally { setLoading(false); }
  }

  async function handleMarkAllRead() {
    try {
      await api.post("/api/notifications/read-all", {});
      setNotifications(notifications.map((n) => ({ ...n, read: true })));
    } catch {
      pushToast({ title: "Couldn't mark all read" });
    }
  }

  async function handleTap(n: NotificationItem) {
    if (!n.read) {
      try { await api.patch(`/api/notifications/${n.id}`, {}); } catch {}
      setNotifications(notifications.map((x) => x.id === n.id ? { ...x, read: true } : x));
    }
    onDone();
    if (n.link) {
      navigate(n.link.view as any, n.link.params);
    }
  }

  const unreadCount = notifications.filter((n) => !n.read).length;

  if (loading) {
    return <div className="py-12 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto text-ink-soft" /></div>;
  }

  return (
    <div className="px-4 pb-6 pt-2 space-y-3">
      {/* Header actions */}
      {notifications.length > 0 && unreadCount > 0 && (
        <button onClick={handleMarkAllRead}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-muted text-xs font-bold text-ink-soft hover:text-rush transition-colors">
          <CheckCheck className="h-3.5 w-3.5" /> Mark all as read ({unreadCount})
        </button>
      )}

      {/* Notification list */}
      {notifications.length === 0 ? (
        <div className="rounded-xl bg-muted/40 p-8 text-center">
          <BellOff className="h-8 w-8 text-ink-soft mx-auto mb-2" />
          <p className="text-sm font-semibold text-ink">No notifications yet</p>
          <p className="text-xs text-ink-soft mt-1">Order updates, ride statuses, and wallet transactions will appear here.</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => handleTap(n)}
              className={`w-full text-left rounded-xl p-3 flex items-start gap-3 transition-colors ${
                n.read ? "bg-card border border-border" : "bg-rush-soft/40 border border-rush/20"
              }`}
            >
              {/* Icon */}
              <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${
                n.read ? "bg-muted text-ink-soft" : "bg-rush/10 text-rush"
              }`}>
                {getNotifIcon(n.type)}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className={`text-sm line-clamp-1 ${n.read ? "font-medium text-ink" : "font-bold text-ink"}`}>
                    {n.title}
                  </p>
                  {!n.read && (
                    <span className="h-2 w-2 rounded-full bg-rush shrink-0" />
                  )}
                </div>
                {n.body && (
                  <p className="text-[11px] text-ink-soft line-clamp-2 mt-0.5">{n.body}</p>
                )}
                <p className="text-[10px] text-ink-soft/70 mt-1">
                  {formatRelativeTime(n.createdAt)}
                </p>
              </div>

              {n.link && <ChevronRight className="h-4 w-4 text-ink-soft shrink-0 mt-1" />}
            </button>
          ))}
        </div>
      )}

      <SheetFooter className="px-0 pt-1">
        <Button variant="outline" className="w-full" onClick={onDone}>Close</Button>
      </SheetFooter>
    </div>
  );
}

function getNotifIcon(type: string) {
  if (type.startsWith("ORDER")) return <Package className="h-4 w-4" />;
  if (type.startsWith("RIDE")) return <Car className="h-4 w-4" />;
  if (type.startsWith("WALLET") || type === "PAYOUT") return <WalletIcon className="h-4 w-4" />;
  if (type.startsWith("KYC")) return <ShieldCheck className="h-4 w-4" />;
  return <Bell className="h-4 w-4" />;
}

