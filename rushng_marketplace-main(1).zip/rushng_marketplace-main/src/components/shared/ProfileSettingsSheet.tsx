"use client";

import { useState, useEffect } from "react";
import {
  Loader2, MapPin, Lock, Bell, Check, Trash2, Plus,
} from "lucide-react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useRush } from "@/lib/store";
import { api, ApiError } from "@/lib/api-client";
import { validateNewPin } from "@/lib/pin-policy";

interface SavedAddress {
  id: string;
  label: string;     // "Home", "Work", "Other"
  address: string;
}

interface NotificationPrefs {
  pushOrders: boolean;
  pushRides: boolean;
  pushWallet: boolean;
  pushMarketing: boolean;
  emailOrders: boolean;
  emailWallet: boolean;
  emailMarketing: boolean;
}

const DEFAULT_PREFS: NotificationPrefs = {
  pushOrders: true,
  pushRides: true,
  pushWallet: true,
  pushMarketing: false,
  emailOrders: true,
  emailWallet: true,
  emailMarketing: false,
};

interface ProfileSettingsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProfileSettingsSheet({ open, onOpenChange }: ProfileSettingsSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-2xl">
        <SheetHeader>
          <SheetTitle>Profile settings</SheetTitle>
        </SheetHeader>
        {open && <SettingsContent onDone={() => onOpenChange(false)} />}
      </SheetContent>
    </Sheet>
  );
}

function SettingsContent({ onDone }: { onDone: () => void }) {
  const { user, pushToast } = useRush();
  const [tab, setTab] = useState<"addresses" | "security" | "notifications">("addresses");

  return (
    <div className="px-4 pb-6 pt-2 space-y-4">
      {/* Tab toggle */}
      <div className="flex gap-2">
        {([
          { id: "addresses", label: "Addresses", icon: MapPin },
          { id: "security", label: "Security", icon: Lock },
          { id: "notifications", label: "Preferences", icon: Bell },
        ] as const).map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-colors ${
                tab === t.id ? "rush-gradient text-white shadow-rush" : "bg-muted text-ink-soft"
              }`}
            >
              <Icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === "addresses" && <AddressesTab />}
      {tab === "security" && <SecurityTab />}
      {tab === "notifications" && <NotificationsTab />}

      <SheetFooter className="px-0 pt-1">
        <Button variant="outline" className="w-full" onClick={onDone}>Done</Button>
      </SheetFooter>
    </div>
  );
}

// ─── Addresses tab ─────────────────────────────────────────────────────────

function AddressesTab() {
  const { pushToast } = useRush();
  const [addresses, setAddresses] = useState<SavedAddress[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [label, setLabel] = useState("Home");
  const [address, setAddress] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadAddresses();
  }, []);

  async function loadAddresses() {
    setLoading(true);
    try {
      const r = await api.get<{ addresses: SavedAddress[] }>("/api/addresses");
      setAddresses(r.addresses || []);
    } catch {
      setAddresses([]);
    } finally { setLoading(false); }
  }

  async function handleAdd() {
    if (address.trim().length < 5) { pushToast({ title: "Enter a valid address" }); return; }
    setSaving(true);
    try {
      await api.post("/api/addresses", { label, address: address.trim() });
      pushToast({ title: "Address saved" });
      setAddress(""); setShowForm(false);
      await loadAddresses();
    } catch (e: any) {
      pushToast({ title: "Save failed", description: e instanceof ApiError ? e.message : undefined });
    } finally { setSaving(false); }
  }

  async function handleDelete(id: string) {
    try {
      await api.delete(`/api/addresses?id=${id}`);
      setAddresses(addresses.filter((a) => a.id !== id));
      pushToast({ title: "Address removed" });
    } catch (e: any) {
      pushToast({ title: "Couldn't remove" });
    }
  }

  if (loading) return <div className="py-8 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto text-ink-soft" /></div>;

  return (
    <div className="space-y-3">
      {addresses.length === 0 && !showForm ? (
        <div className="rounded-xl bg-muted/40 p-6 text-center">
          <MapPin className="h-6 w-6 text-ink-soft mx-auto mb-2" />
          <p className="text-sm font-semibold">No saved addresses</p>
          <p className="text-xs text-ink-soft mt-1">Add your home or work address for faster checkout.</p>
        </div>
      ) : (
        addresses.map((a) => (
          <div key={a.id} className="rounded-xl bg-card border border-border p-3 flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-rush-soft text-rush flex items-center justify-center shrink-0">
              <MapPin className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-ink">{a.label}</p>
              <p className="text-[11px] text-ink-soft line-clamp-2">{a.address}</p>
            </div>
            <button onClick={() => handleDelete(a.id)} className="h-8 w-8 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0">
              <Trash2 className="h-3.5 w-3.5 text-destructive" />
            </button>
          </div>
        ))
      )}

      {showForm ? (
        <div className="rounded-xl bg-muted/40 p-3 space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-ink-soft mb-1">Label</label>
            <div className="flex gap-2">
              {["Home", "Work", "Other"].map((l) => (
                <button key={l} onClick={() => setLabel(l)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold ${label === l ? "rush-gradient text-white" : "bg-card text-ink-soft border border-border"}`}>
                  {l}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-ink-soft mb-1">Address</label>
            <Textarea value={address} onChange={(e) => setAddress(e.target.value)} rows={2} placeholder="House number, street, area, city" />
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={handleAdd} disabled={saving}>{saving && <Loader2 className="h-3 w-3 animate-spin mr-1" />}Save</Button>
            <Button variant="ghost" size="sm" onClick={() => { setShowForm(false); setAddress(""); }}>Cancel</Button>
          </div>
        </div>
      ) : (
        <button onClick={() => setShowForm(true)}
          className="w-full rounded-xl border-2 border-dashed border-border p-3 text-sm font-semibold text-ink-soft hover:border-rush hover:text-rush transition-colors flex items-center justify-center gap-2">
          <Plus className="h-4 w-4" /> Add address
        </button>
      )}
    </div>
  );
}

// ─── Security tab ──────────────────────────────────────────────────────────

function SecurityTab() {
  const { user, pushToast } = useRush();
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);
  // Transaction PIN state
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [savingPin, setSavingPin] = useState(false);
  // Re-auth state — changing an existing PIN requires the current PIN
  // or the account password (server-enforced).
  const [hasPin, setHasPin] = useState(false);
  const [currentPin, setCurrentPin] = useState("");
  const [usePasswordInstead, setUsePasswordInstead] = useState(false);
  const [reauthValue, setReauthValue] = useState("");

  useEffect(() => {
    // /api/auth/me returns a hasPin boolean (never the PIN hash).
    api.get<{ user: { hasPin?: boolean } | null }>("/api/auth/me").then((r) => {
      setHasPin(!!r.user?.hasPin);
    }).catch(() => {});
  }, []);

  async function handleChangePassword() {
    if (newPassword.length < 6) { pushToast({ title: "New password must be at least 6 characters" }); return; }
    if (newPassword !== confirmPassword) { pushToast({ title: "Passwords don't match" }); return; }
    setSaving(true);
    try {
      await api.post("/api/auth/change-password", { oldPassword, newPassword });
      pushToast({ title: "Password changed ✅" });
      setOldPassword(""); setNewPassword(""); setConfirmPassword("");
    } catch (e: any) {
      pushToast({ title: "Change failed", description: e instanceof ApiError ? e.message : undefined });
    } finally { setSaving(false); }
  }

  async function handleSetPin() {
    if (pin.length !== 4) { pushToast({ title: "PIN must be 4 digits" }); return; }
    if (pin !== confirmPin) { pushToast({ title: "PINs don't match" }); return; }
    // Client-side weak-PIN check (same policy the server enforces).
    const weak = validateNewPin(pin);
    if (weak) { pushToast({ title: "PIN too weak", description: weak }); return; }
    if (hasPin && !usePasswordInstead && currentPin.length !== 4) {
      pushToast({ title: "Enter your current PIN to change it" });
      return;
    }
    if (hasPin && usePasswordInstead && !reauthValue) {
      pushToast({ title: "Enter your account password to reset the PIN" });
      return;
    }
    setSavingPin(true);
    try {
      await api.post("/api/auth/set-pin", {
        pin,
        // Server requires re-auth when a PIN already exists.
        ...(hasPin
          ? usePasswordInstead
            ? { password: reauthValue }
            : { currentPin }
          : {}),
      });
      pushToast({ title: "Transaction PIN set ✅" });
      setHasPin(true);
      setPin(""); setConfirmPin(""); setCurrentPin(""); setReauthValue("");
    } catch (e: any) {
      pushToast({ title: "Failed to set PIN", description: e instanceof ApiError ? e.message : undefined });
    } finally { setSavingPin(false); }
  }

  return (
    <div className="space-y-5">
      {/* Change password */}
      <div className="space-y-3">
        <p className="text-[11px] font-bold text-ink-soft uppercase tracking-wide">Password</p>
        <div className="rounded-xl bg-rush-soft/40 p-3 text-xs text-rush-deep flex items-center gap-2">
          <Lock className="h-4 w-4 shrink-0" />
          <span>Change your password. Use at least 6 characters.</span>
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-soft mb-1">Current password</label>
          <Input type="password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} disabled={saving} />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-soft mb-1">New password</label>
          <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} disabled={saving} />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-soft mb-1">Confirm new password</label>
          <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} disabled={saving} />
        </div>
        <Button onClick={handleChangePassword} disabled={saving || !oldPassword || !newPassword} className="w-full">
          {saving && <Loader2 className="h-3 w-3 animate-spin mr-1" />} Change password
        </Button>
      </div>

      {/* Transaction PIN */}
      <div className="space-y-3">
        <p className="text-[11px] font-bold text-ink-soft uppercase tracking-wide">Transaction PIN</p>
        <div className="rounded-xl bg-rush-soft/40 p-3 text-xs text-rush-deep flex items-center gap-2">
          <Lock className="h-4 w-4 shrink-0" />
          <span>{hasPin ? "Update your 4-digit PIN — required for wallet withdrawals and payments." : "Set a 4-digit PIN for wallet withdrawals and payments."}</span>
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-soft mb-1">{hasPin ? "New PIN (4 digits)" : "Enter PIN (4 digits)"}</label>
          <Input
            inputMode="numeric"
            maxLength={4}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
            placeholder="••••"
            className="text-center text-2xl tracking-[0.5em] font-bold"
            disabled={savingPin}
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-soft mb-1">Confirm PIN</label>
          <Input
            inputMode="numeric"
            maxLength={4}
            value={confirmPin}
            onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ""))}
            placeholder="••••"
            className="text-center text-2xl tracking-[0.5em] font-bold"
            disabled={savingPin}
          />
        </div>
        {hasPin && (
          <div className="rounded-xl border border-ink/10 p-3 space-y-2">
            <p className="text-[11px] font-semibold text-ink-soft">Security check — confirm it's you</p>
            {!usePasswordInstead ? (
              <>
                <Input
                  inputMode="numeric"
                  maxLength={4}
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, ""))}
                  placeholder="Current PIN"
                  className="text-center text-xl tracking-[0.4em] font-bold"
                  disabled={savingPin}
                />
                <button
                  type="button"
                  onClick={() => { setUsePasswordInstead(true); setCurrentPin(""); }}
                  className="text-[11px] font-semibold text-rush-deep underline"
                >
                  Forgot your PIN? Verify with your password instead
                </button>
              </>
            ) : (
              <>
                <Input
                  type="password"
                  value={reauthValue}
                  onChange={(e) => setReauthValue(e.target.value)}
                  placeholder="Account password"
                  disabled={savingPin}
                />
                <button
                  type="button"
                  onClick={() => { setUsePasswordInstead(false); setReauthValue(""); }}
                  className="text-[11px] font-semibold text-rush-deep underline"
                >
                  Use your current PIN instead
                </button>
              </>
            )}
          </div>
        )}
        <Button onClick={handleSetPin} disabled={savingPin || pin.length !== 4 || pin !== confirmPin} className="w-full">
          {savingPin && <Loader2 className="h-3 w-3 animate-spin mr-1" />} {hasPin ? "Update PIN" : "Set PIN"}
        </Button>
      </div>
    </div>
  );
}

// ─── Notifications tab ─────────────────────────────────────────────────────

function NotificationsTab() {
  const { pushToast } = useRush();
  const [prefs, setPrefs] = useState<NotificationPrefs>(DEFAULT_PREFS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<{ preferences: NotificationPrefs }>("/api/notifications/preferences")
      .then((r) => setPrefs({ ...DEFAULT_PREFS, ...r.preferences }))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  async function toggle(key: keyof NotificationPrefs) {
    const newPrefs = { ...prefs, [key]: !prefs[key] };
    setPrefs(newPrefs);
    setSaving(true);
    try {
      await api.patch("/api/notifications/preferences", newPrefs);
    } catch {
      // Revert on failure
      setPrefs(prefs);
      pushToast({ title: "Couldn't update preferences" });
    } finally { setSaving(false); }
  }

  if (loading) return <div className="py-8 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto text-ink-soft" /></div>;

  const sections = [
    { title: "Push notifications", keys: [
      { key: "pushOrders", label: "Order updates", desc: "Order placed, confirmed, delivered" },
      { key: "pushRides", label: "Ride updates", desc: "Rider assigned, trip started, completed" },
      { key: "pushWallet", label: "Wallet & payments", desc: "Top-ups, withdrawals, debits" },
      { key: "pushMarketing", label: "Promotions", desc: "Deals, new features" },
    ]},
    { title: "Email notifications", keys: [
      { key: "emailOrders", label: "Order receipts", desc: "Order placed, delivered" },
      { key: "emailWallet", label: "Wallet transactions", desc: "Top-ups, withdrawals" },
      { key: "emailMarketing", label: "Promotions", desc: "Deals, new features" },
    ]},
  ];

  return (
    <div className="space-y-4">
      {sections.map((section) => (
        <div key={section.title}>
          <p className="text-[11px] font-bold text-ink-soft uppercase tracking-wide mb-2">{section.title}</p>
          <div className="rounded-xl bg-card border border-border overflow-hidden divide-y divide-border">
            {section.keys.map((item) => (
              <div key={item.key} className="flex items-center gap-3 p-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink">{item.label}</p>
                  <p className="text-[11px] text-ink-soft">{item.desc}</p>
                </div>
                <Switch
                  checked={prefs[item.key as keyof NotificationPrefs]}
                  onChange={() => toggle(item.key as keyof NotificationPrefs)}
                  disabled={saving}
                />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Switch component ──────────────────────────────────────────────────────

function Switch({ checked, onChange, disabled }: { checked: boolean; onChange: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
        checked ? "bg-rush" : "bg-muted border border-border"
      } ${disabled ? "opacity-50" : ""}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${
          checked ? "translate-x-5" : "translate-x-0"
        }`}
      />
    </button>
  );
}
