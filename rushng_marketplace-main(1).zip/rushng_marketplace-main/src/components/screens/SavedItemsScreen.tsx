"use client";

import { useState } from "react";
import {
  Heart, Store, Package, Wrench, Trash2, ChevronLeft, Loader2,
} from "lucide-react";
import { useRush } from "@/lib/store";
import { api, ApiError } from "@/lib/api-client";
import { naira } from "@/lib/data";
import { BackHeader } from "./CartScreen";

interface SavedItem {
  id: string;
  targetType: string;
  targetId: string;
  createdAt: string;
  target: any;
}

export function SavedItemsScreen() {
  const { navigate, back, pushToast } = useRush();
  const [tab, setTab] = useState<"vendor" | "product" | "provider">("vendor");
  const [items, setItems] = useState<SavedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loaded, setLoaded] = useState<string | null>(null);

  // Load items when tab changes
  if (loaded !== tab) {
    setLoaded(tab);
    setLoading(true);
    api.get<{ items: SavedItem[] }>(`/api/saved-items?type=${tab}`)
      .then((r) => { setItems(r.items); })
      .catch(() => { setItems([]); })
      .finally(() => setLoading(false));
  }

  async function handleRemove(id: string) {
    try {
      await api.delete(`/api/saved-items?id=${id}`);
      setItems(items.filter((i) => i.id !== id));
      pushToast({ title: "Removed" });
    } catch (e: any) {
      pushToast({ title: "Couldn't remove", description: e instanceof ApiError ? e.message : undefined });
    }
  }

  return (
    <div className="pb-6">
      <BackHeader title="Saved items" onBack={back} />

      {/* Tab toggle */}
      <div className="px-4 pt-3">
        <div className="flex gap-2">
          {([
            { id: "vendor", label: "Stores", icon: Store },
            { id: "product", label: "Products", icon: Package },
            { id: "provider", label: "Providers", icon: Wrench },
          ] as const).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-colors ${
                  tab === t.id ? "rush-gradient text-white shadow-rush" : "bg-muted text-ink-soft"
                }`}
              >
                <Icon className="h-3.5 w-3.5" /> {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Items */}
      <div className="px-4 pt-4">
        {loading ? (
          <div className="flex items-center justify-center py-12 text-ink-soft">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl bg-muted/40 p-8 text-center">
            <Heart className="h-8 w-8 text-ink-soft mx-auto mb-2" />
            <p className="text-sm font-semibold text-ink">No saved {tab === "vendor" ? "stores" : tab === "product" ? "products" : "providers"} yet</p>
            <p className="text-xs text-ink-soft mt-1">Tap the heart icon on any item to save it here.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((item) => (
              <div
                key={item.id}
                className="rounded-xl bg-card border border-border p-3 flex items-center gap-3"
              >
                {/* Thumbnail */}
                <div
                  className="h-12 w-12 rounded-xl bg-muted shrink-0 overflow-hidden cursor-pointer"
                  onClick={() => {
                    if (tab === "vendor" && item.target?.slug) navigate("store", { storeSlug: item.target.slug });
                    else if (tab === "product" && item.target?.id) navigate("product", { productId: item.target.id });
                    else if (tab === "provider" && item.target?.slug) navigate("provider", { providerId: item.target.slug });
                  }}
                >
                  {item.target?.logo || item.target?.avatar || (item.target?.images && JSON.parse(item.target.images)[0]) ? (
                    <img
                      src={item.target?.logo || item.target?.avatar || JSON.parse(item.target.images)[0]}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      {tab === "vendor" ? <Store className="h-5 w-5 text-ink-soft" /> :
                       tab === "product" ? <Package className="h-5 w-5 text-ink-soft" /> :
                       <Wrench className="h-5 w-5 text-ink-soft" />}
                    </div>
                  )}
                </div>

                {/* Info */}
                <div
                  className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => {
                    if (tab === "vendor" && item.target?.slug) navigate("store", { storeSlug: item.target.slug });
                    else if (tab === "product" && item.target?.id) navigate("product", { productId: item.target.id });
                    else if (tab === "provider" && item.target?.slug) navigate("provider", { providerId: item.target.slug });
                  }}
                >
                  <p className="text-sm font-bold text-ink line-clamp-1">
                    {item.target?.businessName || item.target?.name || "Unknown"}
                  </p>
                  <p className="text-[11px] text-ink-soft line-clamp-1">
                    {tab === "product" && item.target?.price ? naira(item.target.price) : (item.target?.category || item.target?.location || "")}
                  </p>
                </div>

                {/* Remove */}
                <button
                  onClick={() => handleRemove(item.id)}
                  className="h-8 w-8 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0"
                  aria-label="Remove"
                >
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
