import "server-only";

import { sendEmail } from "./send";
import { naira } from "@/lib/data";

/**
 * Wallet email notifications — sent on deposits, withdrawals, and
 * payout status changes.
 *
 * Each function is best-effort: failures are logged but don't throw.
 * The caller should `void sendWallet...()` or wrap in try/catch.
 */

interface WalletEmailInput {
  name: string;
  email: string;
  userId: string;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  reference?: string;
  description?: string;
  bankName?: string;
}

/** Wallet credited (top-up via Paystack). */
export async function sendWalletCreditEmail(input: WalletEmailInput) {
  try {
    await sendEmail({
      to: { email: input.email, name: input.name, userId: input.userId },
      subject: `Wallet topped up — ${naira(input.amount)} added`,
      html: `
        <h2>Wallet topped up ✅</h2>
        <p>Hi ${input.name},</p>
        <p>${naira(input.amount)} has been added to your Rush wallet.</p>
        <table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:14px;">
          <tr><td style="color:#666;">Amount</td><td><strong>${naira(input.amount)}</strong></td></tr>
          <tr><td style="color:#666;">Previous balance</td><td>${naira(input.balanceBefore)}</td></tr>
          <tr><td style="color:#666;">New balance</td><td><strong>${naira(input.balanceAfter)}</strong></td></tr>
          ${input.reference ? `<tr><td style="color:#666;">Reference</td><td>${input.reference}</td></tr>` : ""}
        </table>
        <p style="margin-top:16px;color:#999;font-size:12px;">You can use your wallet balance to pay for orders, rides, and services on Rush.</p>
      `,
      text: `Hi ${input.name},\n\n${naira(input.amount)} has been added to your Rush wallet.\nNew balance: ${naira(input.balanceAfter)}\n${input.reference ? `Reference: ${input.reference}` : ""}`,
      type: "WALLET_CREDIT",
      idempotencyKey: `wallet-credit:${input.userId}:${input.reference || input.amount}:${Date.now()}`,
    });
  } catch (e: any) {
    console.error("[wallet-email] credit email failed:", e?.message);
  }
}

/** Wallet debited (paid for an order). */
export async function sendWalletDebitEmail(input: WalletEmailInput) {
  try {
    await sendEmail({
      to: { email: input.email, name: input.name, userId: input.userId },
      subject: `Wallet debited — ${naira(input.amount)} for order`,
      html: `
        <h2>Wallet payment processed</h2>
        <p>Hi ${input.name},</p>
        <p>${naira(input.amount)} was debited from your Rush wallet${input.description ? ` for: ${input.description}` : ""}.</p>
        <table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:14px;">
          <tr><td style="color:#666;">Amount</td><td><strong>${naira(input.amount)}</strong></td></tr>
          <tr><td style="color:#666;">Previous balance</td><td>${naira(input.balanceBefore)}</td></tr>
          <tr><td style="color:#666;">New balance</td><td><strong>${naira(input.balanceAfter)}</strong></td></tr>
        </table>
      `,
      text: `Hi ${input.name},\n\n${naira(input.amount)} was debited from your Rush wallet.\nNew balance: ${naira(input.balanceAfter)}`,
      type: "WALLET_DEBIT",
      idempotencyKey: `wallet-debit:${input.userId}:${input.reference || input.amount}:${Date.now()}`,
    });
  } catch (e: any) {
    console.error("[wallet-email] debit email failed:", e?.message);
  }
}

/** Withdrawal initiated — funds are on the way to the bank. */
export async function sendWithdrawalInitiatedEmail(input: WalletEmailInput) {
  try {
    await sendEmail({
      to: { email: input.email, name: input.name, userId: input.userId },
      subject: `Withdrawal initiated — ${naira(input.amount)} to ${input.bankName || "your bank"}`,
      html: `
        <h2>Withdrawal initiated 💸</h2>
        <p>Hi ${input.name},</p>
        <p>Your withdrawal of ${naira(input.amount)} is being processed and will arrive in your bank account within 1-5 minutes.</p>
        <table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:14px;">
          <tr><td style="color:#666;">Amount</td><td><strong>${naira(input.amount)}</strong></td></tr>
          <tr><td style="color:#666;">Bank</td><td>${input.bankName || "—"}</td></tr>
          <tr><td style="color:#666;">Reference</td><td>${input.reference || "—"}</td></tr>
          <tr><td style="color:#666;">Wallet balance after</td><td>${naira(input.balanceAfter)}</td></tr>
        </table>
        <p style="margin-top:16px;color:#999;font-size:12px;">You'll receive another email when the funds arrive in your bank account.</p>
      `,
      text: `Hi ${input.name},\n\nYour withdrawal of ${naira(input.amount)} to ${input.bankName || "your bank"} is being processed.\nReference: ${input.reference || "—"}`,
      type: "WITHDRAWAL_INITIATED",
      idempotencyKey: `withdrawal-initiated:${input.userId}:${input.reference || Date.now()}`,
    });
  } catch (e: any) {
    console.error("[wallet-email] withdrawal-initiated email failed:", e?.message);
  }
}

/** Withdrawal completed — funds arrived in the bank. */
export async function sendWithdrawalPaidEmail(input: WalletEmailInput) {
  try {
    await sendEmail({
      to: { email: input.email, name: input.name, userId: input.userId },
      subject: `Withdrawal completed — ${naira(input.amount)} received`,
      html: `
        <h2>Withdrawal completed ✅</h2>
        <p>Hi ${input.name},</p>
        <p>${naira(input.amount)} has been transferred to your bank account${input.bankName ? ` at ${input.bankName}` : ""}.</p>
        <table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:14px;">
          <tr><td style="color:#666;">Amount</td><td><strong>${naira(input.amount)}</strong></td></tr>
          <tr><td style="color:#666;">Bank</td><td>${input.bankName || "—"}</td></tr>
          <tr><td style="color:#666;">Reference</td><td>${input.reference || "—"}</td></tr>
        </table>
      `,
      text: `Hi ${input.name},\n\n${naira(input.amount)} has been transferred to your bank account.\nReference: ${input.reference || "—"}`,
      type: "WITHDRAWAL_PAID",
      idempotencyKey: `withdrawal-paid:${input.userId}:${input.reference || Date.now()}`,
    });
  } catch (e: any) {
    console.error("[wallet-email] withdrawal-paid email failed:", e?.message);
  }
}

/** Withdrawal failed — wallet refunded. */
export async function sendWithdrawalFailedEmail(input: WalletEmailInput) {
  try {
    await sendEmail({
      to: { email: input.email, name: input.name, userId: input.userId },
      subject: `Withdrawal failed — ${naira(input.amount)} refunded to wallet`,
      html: `
        <h2>Withdrawal failed ❌</h2>
        <p>Hi ${input.name},</p>
        <p>Your withdrawal of ${naira(input.amount)} could not be completed${input.description ? `: ${input.description}` : ""}.</p>
        <p>The amount has been <strong>refunded to your Rush wallet</strong>. Your new balance is ${naira(input.balanceAfter)}.</p>
        <p style="margin-top:16px;color:#999;font-size:12px;">If this keeps happening, please check your bank account details or contact support.</p>
      `,
      text: `Hi ${input.name},\n\nYour withdrawal of ${naira(input.amount)} failed. The amount has been refunded to your wallet.\nNew balance: ${naira(input.balanceAfter)}`,
      type: "WITHDRAWAL_FAILED",
      idempotencyKey: `withdrawal-failed:${input.userId}:${input.reference || Date.now()}`,
    });
  } catch (e: any) {
    console.error("[wallet-email] withdrawal-failed email failed:", e?.message);
  }
}
