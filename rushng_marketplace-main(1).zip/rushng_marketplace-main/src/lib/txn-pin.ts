import "server-only";

/**
 * Transaction PIN — shared security module.
 *
 * A 4-digit PIN guards every movement of money OUT of a wallet:
 *   - Customer wallet withdrawals (/api/wallet/withdraw)
 *   - Vendor payout withdrawals (/api/vendor/payouts/withdraw)
 *   - Wallet payments at checkout (/api/wallet/debit)
 *
 * It is deliberately NOT required for funding the wallet: a top-up
 * moves money IN and is authorized end-to-end by the cardholder's
 * bank (Paystack 3DS), so an extra PIN would add friction without
 * adding protection — the same reasoning used by OPay, Moniepoint
 * and Cash App.
 *
 * ─── Security properties ─────────────────────────────────────────
 *
 * 1. bcrypt hashing (cost 10, per-user random salt). A 4-digit PIN
 *    only has 10,000 combinations, so a deterministic hash
 *    (HMAC-SHA256 with a global key — the previous implementation)
 *    could be fully precomputed the moment the DB + secret leaked.
 *    bcrypt's per-user salt makes precomputation impossible.
 *
 * 2. Brute-force lockout. Failed verifications are tracked
 *    atomically on the user document (pinFailedAttempts). After
 *    5 failures the PIN locks for 15 minutes, doubling per lock
 *    (15 → 30 → 60 min cap) via pinLockCount. The lock applies
 *    server-side to every guarded route, not just the UI.
 *
 * 3. Re-authentication to change the PIN. set-pin requires the
 *    current PIN (verified through the same lockout) or the
 *    account password — so a stolen session alone cannot take
 *    over payouts.
 *
 * 4. Weak-PIN rejection on set ("1234", "0000", repeats, runs).
 *
 * 5. Generic errors. Responses never reveal whether an account
 *    exists; lockout messages leak no internal detail. PIN values
 *    are never logged.
 *
 * Mongo is schemaless — pinFailedAttempts / pinLockedUntil /
 * pinLockCount materialize on first write, no migration needed.
 */

import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { notifyUser } from "@/lib/notify";
import { PIN_LENGTH, sanitizePin } from "@/lib/pin-policy";

// Re-export the client-safe policy so existing importers keep working.
export { PIN_LENGTH, validateNewPin, sanitizePin } from "@/lib/pin-policy";

// ─── Tunables ────────────────────────────────────────────────────────

export const PIN_MAX_ATTEMPTS = 5;
export const PIN_LOCK_BASE_MS = 15 * 60_000; // 15 minutes
export const PIN_LOCK_MAX_MS = 60 * 60_000; // 60 minutes cap
export const PIN_BCRYPT_COST = 10;

// ─── Error type ──────────────────────────────────────────────────────

export type PinErrorCode =
  | "PIN_REQUIRED" // no PIN provided in the request body
  | "PIN_INVALID" // wrong PIN (attempts remaining)
  | "PIN_LOCKED" // temporarily locked, retry later
  | "PIN_SETUP_REQUIRED" // user has no PIN yet
  | "PIN_WEAK"; // rejected at set time (common/pattern PIN)

export class PinError extends Error {
  code: PinErrorCode;
  status: number;
  attemptsRemaining?: number;
  retryAfterSeconds?: number;

  constructor(
    code: PinErrorCode,
    status: number,
    message: string,
    extra?: { attemptsRemaining?: number; retryAfterSeconds?: number },
  ) {
    super(message);
    this.name = "PinError";
    this.code = code;
    this.status = status;
    if (extra?.attemptsRemaining !== undefined)
      this.attemptsRemaining = extra.attemptsRemaining;
    if (extra?.retryAfterSeconds !== undefined)
      this.retryAfterSeconds = extra.retryAfterSeconds;
  }
}

// ─── Hashing ─────────────────────────────────────────────────────────

export async function hashTransactionPin(pin: string): Promise<string> {
  return bcrypt.hash(sanitizePin(pin), PIN_BCRYPT_COST);
}

export async function compareTransactionPin(
  pin: string,
  hash: string,
): Promise<boolean> {
  return bcrypt.compare(sanitizePin(pin), hash);
}

// ─── The guard used by every money-out route ─────────────────────────

interface PinUserRow {
  transactionPin: string | null;
  pinFailedAttempts?: number | null;
  pinLockedUntil?: Date | string | null;
  pinLockCount?: number | null;
}

/**
 * Require a correct transaction PIN for `userId`.
 *
 * Throws PinError with a UI-actionable code:
 *   - PIN_SETUP_REQUIRED (403): no PIN set yet — client should open
 *     the "create PIN" flow, then retry the original action.
 *   - PIN_LOCKED (429): too many wrong tries; retryAfterSeconds set.
 *   - PIN_INVALID (403): wrong PIN; attemptsRemaining set.
 *   - PIN_REQUIRED (400): body pin missing/malformed.
 *
 * On success, failed-attempt counters are reset.
 */
export async function requirePinVerified(
  userId: string,
  pin: unknown,
): Promise<void> {
  const sanitized = sanitizePin(pin);

  const user = (await db.user.findUnique({
    where: { id: userId },
    select: {
      transactionPin: true,
      pinFailedAttempts: true,
      pinLockedUntil: true,
      pinLockCount: true,
    },
  })) as PinUserRow | null;

  if (!user) {
    throw new PinError("PIN_REQUIRED", 401, "Session user not found.");
  }

  // 1. Setup gate — no PIN yet. The client flips its PIN pad into
  //    "create PIN" mode and retries afterwards.
  if (!user.transactionPin) {
    throw new PinError(
      "PIN_SETUP_REQUIRED",
      403,
      "Set a transaction PIN to continue — it protects your withdrawals and payments.",
    );
  }

  // 2. Lockout gate — checked BEFORE any hash comparison so even the
  //    correct PIN is refused while locked (matches banking apps).
  if (user.pinLockedUntil) {
    const lockedUntil = new Date(user.pinLockedUntil);
    if (lockedUntil.getTime() > Date.now()) {
      const retryAfterSeconds = Math.max(
        1,
        Math.ceil((lockedUntil.getTime() - Date.now()) / 1000),
      );
      throw new PinError(
        "PIN_LOCKED",
        429,
        `Too many incorrect PIN attempts. Try again in ${Math.ceil(retryAfterSeconds / 60)} minute(s).`,
        { retryAfterSeconds },
      );
    }
  }

  // 3. Input shape — malformed input is rejected without consuming an
  //    attempt (attempts are only burned on genuine 4-digit guesses).
  if (sanitized.length !== PIN_LENGTH) {
    throw new PinError(
      "PIN_REQUIRED",
      400,
      `Enter your ${PIN_LENGTH}-digit transaction PIN.`,
    );
  }

  // 4. Verify.
  const ok = await compareTransactionPin(sanitized, user.transactionPin);

  if (!ok) {
    const attempts = (user.pinFailedAttempts ?? 0) + 1;
    const remaining = Math.max(0, PIN_MAX_ATTEMPTS - attempts);

    // Atomic increment — safe under concurrent requests.
    await db.user.updateMany({
      where: { id: userId },
      data: { pinFailedAttempts: { increment: 1 } },
    });

    if (attempts >= PIN_MAX_ATTEMPTS) {
      // Lock with escalation: 15 → 30 → 60 min (capped).
      const lockCount = (user.pinLockCount ?? 0) + 1;
      const lockMs = Math.min(
        PIN_LOCK_BASE_MS * Math.pow(2, lockCount - 1),
        PIN_LOCK_MAX_MS,
      );
      const lockedUntil = new Date(Date.now() + lockMs);

      await db.user.updateMany({
        where: { id: userId },
        data: {
          pinFailedAttempts: 0,
          pinLockedUntil: lockedUntil,
          pinLockCount: { increment: 1 },
        },
      });

      // Security notification (in-app; never blocks the response).
      void notifyUser({
        userId,
        type: "SYSTEM",
        title: "Transaction PIN locked",
        body: `Too many incorrect PIN attempts. Your PIN is locked for ${Math.round(lockMs / 60000)} minutes. If this wasn't you, change your password immediately.`,
      }).catch(() => {});

      throw new PinError(
        "PIN_LOCKED",
        429,
        `Too many incorrect PIN attempts. Your PIN is locked for ${Math.round(lockMs / 60000)} minutes.`,
        { retryAfterSeconds: Math.ceil(lockMs / 1000) },
      );
    }

    throw new PinError(
      "PIN_INVALID",
      403,
      remaining === 1
        ? "Incorrect PIN. 1 attempt remaining before your PIN is temporarily locked."
        : `Incorrect PIN. ${remaining} attempts remaining.`,
      { attemptsRemaining: remaining },
    );
  }

  // 5. Success — clear failure counters (keep lock history).
  if ((user.pinFailedAttempts ?? 0) > 0) {
    await db.user
      .updateMany({
        where: { id: userId },
        data: { pinFailedAttempts: 0 },
      })
      .catch(() => {});
  }
}

/**
 * Turn a thrown PinError into a JSON Response. Use in route catch
 * blocks: `if (err instanceof PinError) return pinErrorResponse(err);`
 */
export function pinErrorResponse(err: PinError): Response {
  const body: Record<string, unknown> = {
    error: err.message,
    code: err.code,
  };
  if (err.attemptsRemaining !== undefined)
    body.attemptsRemaining = err.attemptsRemaining;
  if (err.retryAfterSeconds !== undefined)
    body.retryAfterSeconds = err.retryAfterSeconds;
  return new Response(JSON.stringify(body), {
    status: err.status,
    headers: { "content-type": "application/json" },
  });
}
