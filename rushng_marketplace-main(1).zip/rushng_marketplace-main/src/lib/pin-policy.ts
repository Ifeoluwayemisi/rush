/**
 * Transaction PIN policy — client-safe pure functions.
 *
 * Shared by the server guard (src/lib/txn-pin.ts) and the client UI
 * (PinPadModal, ProfileSettingsSheet) so both sides reject weak PINs
 * with the exact same rules and messages. This module must stay free
 * of server-only imports.
 */

export const PIN_LENGTH = 4;

/** Top common 4-digit PINs (leaked PIN studies) + trivial patterns. */
export const WEAK_PINS = new Set([
  // all repeated digits
  "0000", "1111", "2222", "3333", "4444",
  "5555", "6666", "7777", "8888", "9999",
  // runs & the most-used codes from breach data
  "0123", "1234", "2345", "3210", "4321", "5678", "6789", "7890", "8765", "9876",
  "1004", "1122", "1212", "1313", "1010", "2000", "2020", "2580", "6969", "1379",
]);

/** Normalize user input to digits only. */
export function sanitizePin(input: unknown): string {
  return typeof input === "string" ? input.replace(/\D/g, "") : "";
}

/**
 * Validate a NEW pin. Returns a human-readable error message, or
 * null when the PIN is acceptable.
 */
export function validateNewPin(pin: string): string | null {
  const sanitized = sanitizePin(pin);
  if (sanitized.length !== PIN_LENGTH) {
    return `PIN must be exactly ${PIN_LENGTH} digits.`;
  }
  if (WEAK_PINS.has(sanitized)) {
    return "That PIN is too common or predictable. Choose a harder one — avoid repeats and runs like 1234.";
  }
  return null;
}

/** Machine-readable codes the PIN APIs return, for the client to branch on. */
export const PIN_ERROR_CODES = {
  SETUP_REQUIRED: "PIN_SETUP_REQUIRED",
  INVALID: "PIN_INVALID",
  LOCKED: "PIN_LOCKED",
  REQUIRED: "PIN_REQUIRED",
  WEAK: "PIN_WEAK",
  CURRENT_PIN_REQUIRED: "CURRENT_PIN_REQUIRED",
} as const;
