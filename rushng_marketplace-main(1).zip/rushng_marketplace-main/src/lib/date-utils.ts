/**
 * Date formatting utilities — all output in the user's local timezone
 * (Africa/Lagos by default for Rush's Nigerian audience).
 *
 * Previously the app used `.toISOString()` which always outputs UTC,
 * making order times appear 1 hour behind Lagos time (WAT = UTC+1).
 * These helpers format dates in WAT so the UI shows the correct time.
 */

/** Lagos timezone — West Africa Time (UTC+1). */
export const RUSH_TIMEZONE = "Africa/Lagos";

/**
 * Format a date as a short time string: "5:30 PM"
 * Uses the user's browser locale but forces the timezone to Lagos.
 */
export function formatTime(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleTimeString("en-NG", {
    hour: "numeric",
    minute: "2-digit",
    timeZone: RUSH_TIMEZONE,
  });
}

/**
 * Format a date as a short date string: "25 Sep 2025"
 */
export function formatDate(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-NG", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: RUSH_TIMEZONE,
  });
}

/**
 * Format a date as date + time: "25 Sep, 5:30 PM"
 */
export function formatDateTime(date: string | Date): string {
  return `${formatDate(date)}, ${formatTime(date)}`;
}

/**
 * Format a relative time: "Just now", "5m ago", "3h ago", "2d ago"
 */
export function formatRelativeTime(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return formatDate(d);
}
