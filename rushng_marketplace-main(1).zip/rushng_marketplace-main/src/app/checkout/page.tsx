// src/app/checkout/page.tsx
"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

function CheckoutContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const reference = searchParams.get("reference") || searchParams.get("trxref");
  const [status, setStatus] = useState("Verifying payment...");

  useEffect(() => {
    if (!reference) {
      router.replace("/");
      return;
    }

    async function verify() {
      try {
        const res = await fetch("/api/payments/verify", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ reference }),
        });

        const data = await res.json();

        if (res.ok) {
          setStatus("Payment verified successfully! Redirecting...");
          setTimeout(() => router.replace("/"), 1500);
        } else {
          setStatus(data.error || data.message || "Verification failed on server.");
        }
      } catch (err) {
        console.error("Verification error:", err);
        setStatus("Network error during verification. Please try again.");
      }
    }

    verify();
  }, [reference, router]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
      <Loader2 className="h-8 w-8 animate-spin text-rush mb-4" />
      <p className="text-sm font-semibold text-ink">{status}</p>
    </div>
  );
}

export default function CheckoutReturnPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
          <Loader2 className="h-8 w-8 animate-spin text-rush mb-4" />
          <p className="text-sm font-semibold text-ink">Loading checkout...</p>
        </div>
      }
    >
      <CheckoutContent />
    </Suspense>
  );
}
