import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { resolveAccountNumber } from "@/lib/payments/paystack";

/**
 * POST /api/wallet/bank-account/resolve
 *
 * Body: { accountNumber: string, bankCode: string }
 *
 * Resolves an account number to its account name via Paystack.
 * Used by the customer's bank-account setup for wallet withdrawals.
 */
export async function POST(req: NextRequest) {
  try {
    await requireUser();

    const body = await req.json();
    const { accountNumber, bankCode } = body;

    if (!accountNumber || !bankCode) {
      return NextResponse.json(
        { error: "accountNumber and bankCode are required." },
        { status: 400 },
      );
    }

    const sanitized = String(accountNumber).replace(/\D/g, "");
    if (sanitized.length !== 10) {
      return NextResponse.json(
        { error: "Account number must be 10 digits." },
        { status: 400 },
      );
    }

    const resolved = await resolveAccountNumber(sanitized, String(bankCode));

    return NextResponse.json({
      accountNumber: resolved.accountNumber,
      accountName: resolved.accountName,
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[wallet/bank-account/resolve POST] error", err);
    return NextResponse.json(
      { error: err?.message || "Failed to resolve account." },
      { status: 500 },
    );
  }
}
