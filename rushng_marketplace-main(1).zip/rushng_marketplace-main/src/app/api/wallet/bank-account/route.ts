import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { createTransferRecipient, resolveAccountNumber } from "@/lib/payments/paystack";

/**
 * POST /api/wallet/bank-account
 *
 * Body: { accountNumber, bankCode, bankName }
 *
 * Saves the verified bank account on the USER record (not vendor) and
 * creates a Paystack transfer recipient. Used for customer wallet
 * withdrawals.
 *
 * Since MongoDB is schemaless, we just set these fields on the user doc
 * directly — no migration needed.
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    const body = await req.json();
    const { accountNumber, bankCode, bankName } = body;

    if (!accountNumber || !bankCode || !bankName) {
      return NextResponse.json(
        { error: "accountNumber, bankCode, and bankName are required." },
        { status: 400 },
      );
    }

    const sanitizedAccount = String(accountNumber).replace(/\D/g, "");
    if (sanitizedAccount.length !== 10) {
      return NextResponse.json(
        { error: "Account number must be 10 digits." },
        { status: 400 },
      );
    }

    // 1. Resolve to confirm the account name.
    const resolved = await resolveAccountNumber(sanitizedAccount, String(bankCode));

    // 2. Create the Paystack transfer recipient.
    const recipient = await createTransferRecipient(
      resolved.accountName,
      sanitizedAccount,
      String(bankCode),
    );

    // 3. Save to the user record.
    await db.user.update({
      where: { id: user.id },
      data: {
        bankAccountNumber: sanitizedAccount,
        bankCode: String(bankCode),
        bankName: String(bankName),
        bankAccountName: resolved.accountName,
        paystackRecipientCode: recipient.recipientCode,
      },
    });

    return NextResponse.json({
      ok: true,
      bankAccount: {
        accountNumber: sanitizedAccount,
        accountName: resolved.accountName,
        bankName: String(bankName),
        bankCode: String(bankCode),
        recipientCode: recipient.recipientCode,
      },
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[wallet/bank-account POST] error", err);
    return NextResponse.json(
      { error: err?.message || "Failed to save bank account." },
      { status: 500 },
    );
  }
}

/**
 * GET /api/wallet/bank-account
 *
 * Returns the user's saved bank account (or null).
 */
export async function GET() {
  try {
    const user = await requireUser();

    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: {
        bankAccountNumber: true,
        bankCode: true,
        bankName: true,
        bankAccountName: true,
        paystackRecipientCode: true,
      },
    });

    if (!fresh?.bankAccountNumber) {
      return NextResponse.json({ bankAccount: null });
    }

    return NextResponse.json({
      bankAccount: {
        accountNumber: fresh.bankAccountNumber,
        accountName: fresh.bankAccountName,
        bankName: fresh.bankName,
        bankCode: fresh.bankCode,
        recipientCode: fresh.paystackRecipientCode,
      },
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[wallet/bank-account GET] error", err);
    return NextResponse.json(
      { error: err?.message || "Failed to load bank account." },
      { status: 500 },
    );
  }
}
