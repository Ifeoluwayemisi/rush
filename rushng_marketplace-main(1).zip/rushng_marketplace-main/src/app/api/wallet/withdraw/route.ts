import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { randomBytes } from "node:crypto";
import { initiateTransfer } from "@/lib/payments/paystack";
import { enforceRateLimit } from "@/lib/rate-limit";
import { notifyUser } from "@/lib/notify";
import { PinError, pinErrorResponse, requirePinVerified } from "@/lib/txn-pin";
import {
  sendWithdrawalInitiatedEmail,
  sendWithdrawalFailedEmail,
} from "@/lib/email/wallet";

const MIN_WITHDRAWAL = 1000;

/**
 * POST /api/wallet/withdraw
 *
 * Body: { amount: number, pin: string }
 *
 * A valid 4-digit transaction PIN is ALWAYS required (money is
 * leaving the wallet). Users without a PIN get PIN_SETUP_REQUIRED
 * and are guided through creation by the client before retrying.
 * Wrong attempts count toward a temporary lockout — see
 * src/lib/txn-pin.ts.
 */
export async function POST(req: NextRequest) {
  const blocked = enforceRateLimit(req, "wallet-withdraw", { limit: 10, windowMs: 60_000 });
  if (blocked) return blocked;

  try {
    const user = await requireUser();
    const body = await req.json();
    const amount = Number(body.amount);
    const pin = body.pin; // 4-digit transaction PIN

    // ─── PIN verification (always enforced) ───────────────────────────
    try {
      await requirePinVerified(user.id, pin);
    } catch (err) {
      if (err instanceof PinError) return pinErrorResponse(err);
      throw err;
    }

    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Enter a valid amount." }, { status: 400 });
    }
    if (amount < MIN_WITHDRAWAL) {
      return NextResponse.json(
        { error: `Minimum withdrawal is ₦${MIN_WITHDRAWAL.toLocaleString()}.` },
        { status: 400 },
      );
    }

    // ─── Load bank account ────────────────────────────────────────────
    const freshUser = await db.user.findUnique({
      where: { id: user.id },
      select: {
        name: true,
        bankAccountNumber: true,
        bankAccountName: true,
        bankName: true,
        paystackRecipientCode: true,
      },
    });
    if (!freshUser?.paystackRecipientCode) {
      return NextResponse.json(
        {
          error:
            "Add a bank account before withdrawing. Go to Account → Rush Wallet → Withdraw → Add bank account.",
        },
        { status: 400 },
      );
    }

    // ─── Load wallet ──────────────────────────────────────────────────
    const wallet = await db.wallet.findUnique({ where: { userId: user.id } });
    if (!wallet) {
      return NextResponse.json(
        { error: "You don't have a Rush wallet." },
        { status: 404 },
      );
    }

    const balanceBefore = wallet.balance ?? 0;
    if (balanceBefore < amount) {
      return NextResponse.json(
        {
          error: `Insufficient balance. You have ₦${balanceBefore.toLocaleString()}.`,
          balance: balanceBefore,
          requested: amount,
        },
        { status: 402 },
      );
    }

    // ─── Atomic debit (compare-and-swap) ──────────────────────────────
    const debitResult = await db.wallet.updateMany({
      where: { id: wallet.id, balance: { gte: amount } },
      data: { balance: { decrement: amount } },
    });
    if (debitResult.count === 0) {
      return NextResponse.json(
        { error: "Wallet balance changed during withdrawal. Please try again." },
        { status: 409 },
      );
    }

    const balanceAfter = balanceBefore - amount;

    // ─── Ledger entry ─────────────────────────────────────────────────
    try {
      await db.walletLedgerEntry.create({
        data: {
          id: randomBytes(12).toString("hex"),
          walletId: wallet.id,
          type: "DEBIT",
          amount,
          balanceBefore,
          balanceAfter,
          description: `Withdrawal to ${freshUser.bankName} (${freshUser.bankAccountNumber})`,
          createdAt: new Date(),
        },
      });
    } catch (ledgerErr: any) {
      console.error("[wallet/withdraw] ledger entry failed:", ledgerErr?.message);
    }

    // ─── Create Payout record ────────────────────────────────────────
    // vendorId=null + userId=user.id tells the webhook this is a customer
    // withdrawal (not a vendor payout). On transfer.failed, the webhook
    // refunds the customer's wallet.
    const payoutId = randomBytes(12).toString("hex");
    await db.payout.create({
      data: {
        id: payoutId,
        vendorId: null,       // null = customer withdrawal
        userId: user.id,      // customer's user id
        amount,
        currency: "NGN",
        status: "PENDING",
        recipientCode: freshUser.paystackRecipientCode,
        bankAccountNumber: freshUser.bankAccountNumber,
        bankAccountName: freshUser.bankAccountName,
        bankName: freshUser.bankName,
        description: `Wallet withdrawal by ${freshUser.name}`,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    });

    // ─── Call Paystack ────────────────────────────────────────────────
    try {
      const transfer = await initiateTransfer(
        freshUser.paystackRecipientCode,
        amount,
        `Rush wallet withdrawal — ${freshUser.name}`,
      );

      await db.payout.update({
        where: { id: payoutId },
        data: {
          reference: transfer.reference,
          transferCode: transfer.transferCode,
          providerResponse: JSON.stringify(transfer),
        },
      });

      console.log(
        `[wallet/withdraw] user=${user.id} payout=${payoutId} amount=₦${amount} transfer=${transfer.transferCode}`,
      );

      // ─── In-app notification + email ──────────────────────────────
      void notifyUser({
        userId: user.id,
        type: "PAYOUT",
        title: `Withdrawal initiated — ₦${amount.toLocaleString()}`,
        body: `Funds are on the way to ${freshUser.bankName}. Arrives in 1-5 minutes.`,
      });
      void sendWithdrawalInitiatedEmail({
        name: freshUser.name,
        email: user.email,
        userId: user.id,
        amount,
        balanceBefore,
        balanceAfter,
        reference: transfer.reference,
        bankName: freshUser.bankName || undefined,
      });

      return NextResponse.json({
        ok: true,
        payout: {
          id: payoutId,
          amount,
          status: "PENDING",
          transferCode: transfer.transferCode,
          bankName: freshUser.bankName,
        },
        message:
          "Withdrawal initiated. Funds will arrive in your bank account within 1-5 minutes.",
      });
    } catch (paystackErr: any) {
      // Paystack failed AFTER debit — reverse the debit.
      console.error(
        `[wallet/withdraw] Paystack initiate failed for ${payoutId}:`,
        paystackErr?.message,
      );
      await db.payout.update({
        where: { id: payoutId },
        data: {
          status: "FAILED",
          failureReason: paystackErr?.message || "Paystack initiate failed",
        },
      });
      // Refund the wallet.
      await db.wallet.updateMany({
        where: { id: wallet.id },
        data: { balance: { increment: amount } },
      });
      try {
        await db.walletLedgerEntry.create({
          data: {
            id: randomBytes(12).toString("hex"),
            walletId: wallet.id,
            type: "CREDIT",
            amount,
            balanceBefore: balanceAfter,
            balanceAfter,
            description: `Refund — withdrawal ${payoutId} failed at Paystack`,
            createdAt: new Date(),
          },
        });
      } catch (_) {}

      // ─── In-app notification + email (refund) ──────────────────────
      void notifyUser({
        userId: user.id,
        type: "PAYOUT",
        title: `Withdrawal failed — ₦${amount.toLocaleString()} refunded`,
        body: `The transfer to ${freshUser.bankName} failed. Your wallet has been refunded.`,
      });
      void sendWithdrawalFailedEmail({
        name: freshUser.name,
        email: user.email,
        userId: user.id,
        amount,
        balanceBefore: balanceAfter,
        balanceAfter: balanceAfter + amount,
        description: paystackErr?.message,
      });

      return NextResponse.json(
        {
          error:
            `Paystack couldn't process the transfer: ${paystackErr?.message || "unknown error"}. ` +
            `Your wallet balance has been refunded.`,
        },
        { status: 502 },
      );
    }
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[wallet/withdraw POST] error", err);
    return NextResponse.json(
      { error: err?.message || "Failed to process withdrawal." },
      { status: 500 },
    );
  }
}
