import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getPaymentProvider } from "@/lib/payments/provider";
import { sendPaymentNotification } from "@/lib/email";
import { creditVendorPending } from "@/lib/payments/vendor-wallet";
import { notifyUser } from "@/lib/notify";
import { sendWalletCreditEmail } from "@/lib/email/wallet";

/**
 * POST /api/payments/verify
 *
 * Body: { reference: string }
 *
 * Verifies a Paystack transaction by reference. Updates the matching
 * Payment record and (if successful) advances the order status.
 *
 * This is the primary success path — called by the frontend when
 * Paystack redirects back to the app with the reference in the URL.
 * The webhook (separately) is the authoritative backstop in case the
 * user closes the tab before the redirect completes.
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { reference } = body;

    if (!reference) {
      return NextResponse.json({ error: "reference is required" }, { status: 400 });
    }

    const payment = await db.payment.findUnique({
      where: { reference },
    });
    if (!payment) {
      return NextResponse.json({ error: "Payment reference not found" }, { status: 404 });
    }
    if (payment.customerId !== user.id) {
      return NextResponse.json(
        { error: "This payment wasn't initiated by you" },
        { status: 403 },
      );
    }
    if (payment.status === "SUCCESS") {
      return NextResponse.json({
        alreadyVerified: true,
        payment: { status: "SUCCESS", reference, amount: payment.amount },
      });
    }

    // Fetch the matching order separately — Payment doesn't have a
    // foreign-key relation to Order in the SQLite schema (and a
    // non-required relation would need an additional index column on
    // Order). Cheap enough to just do a second query.
    const order = payment.orderId
      ? await db.order.findUnique({ where: { id: payment.orderId } })
      : null;

    const provider = getPaymentProvider();
    const result = await provider.verify(reference);

    const newStatus =
      result.status === "success" ? "SUCCESS" :
      result.status === "pending" ? "PENDING" :
      result.status === "abandoned" ? "ABANDONED" : "FAILED";

    // ⚠ Amount re-check. Previously, if the customer manipulated the
    // order total (e.g. via negative quantities or a forged
    // deliveryFee — both now blocked at order creation, but defense
    // in depth) and Paystack charged a different amount, we'd still
    // mark the order CONFIRMED. We now require the gateway's reported
    // amount to match the order total within 1 NGN (rounding grace for
    // kobo conversion).
    //
    // We skip this check for the mock provider because its `verify`
    // always returns `amountNaira: 0` (the mock doesn't know about
    // the order — the caller already does).
    if (
      newStatus === "SUCCESS" &&
      provider.name !== "mock" &&
      order &&
      result.amountNaira > 0 &&
      Math.abs(result.amountNaira - order.total) > 1
    ) {
      console.error(
        `[payments/verify] amount mismatch for ${reference}: ` +
          `gateway=${result.amountNaira} naira, order=${order.total} naira`,
      );
      await db.payment.update({
        where: { reference },
        data: {
          status: "FAILED",
          providerResponse: JSON.stringify({
            ...result,
            mismatchReason: `amount ${result.amountNaira} ≠ order.total ${order.total}`,
          }),
        },
      });
      return NextResponse.json(
        {
          status: "FAILED",
          reason: "amount_mismatch",
          expected: order.total,
          received: result.amountNaira,
          orderId: payment.orderId,
        },
        { status: 402 },
      );
    }

    await db.payment.update({
      where: { reference },
      data: {
        status: newStatus,
        providerResponse: JSON.stringify(result),
      },
    });

    // ─── Wallet top-up flow ───────────────────────────────────────────
    // If the payment has no orderId, it's a wallet top-up. Credit the
    // customer's wallet with the payment amount.
    if (newStatus === "SUCCESS" && !order && payment.customerId) {
      try {
        const wallet = await db.wallet.findUnique({
          where: { userId: payment.customerId },
        });
        if (wallet) {
          const balanceBefore = wallet.balance ?? 0;
          const balanceAfter = balanceBefore + (payment.amount ?? 0);
          await db.wallet.updateMany({
            where: { id: wallet.id },
            data: { balance: { increment: payment.amount ?? 0 } },
          });
          // Ledger entry.
          try {
            const { randomBytes } = await import("node:crypto");
            await db.walletLedgerEntry.create({
              data: {
                id: randomBytes(12).toString("hex"),
                walletId: wallet.id,
                type: "CREDIT",
                amount: payment.amount ?? 0,
                balanceBefore,
                balanceAfter,
                description: `Wallet top-up via Paystack (${reference})`,
                createdAt: new Date(),
              },
            });
          } catch (ledgerErr: any) {
            console.error("[payments/verify] wallet ledger entry failed:", ledgerErr?.message);
          }
          console.log(
            `[payments/verify] wallet top-up: user=${payment.customerId} credited ₦${payment.amount} (₦${balanceBefore} → ₦${balanceAfter})`,
          );

          // ─── In-app notification + email ──────────────────────────
          void notifyUser({
            userId: payment.customerId,
            type: "WALLET_UPDATE",
            title: `Wallet topped up — ₦${(payment.amount ?? 0).toLocaleString()}`,
            body: `Your wallet balance is now ₦${balanceAfter.toLocaleString()}.`,
          });
          // Fetch user email for the email notification.
          const walletUser = await db.user.findUnique({
            where: { id: payment.customerId },
            select: { name: true, email: true },
          });
          if (walletUser) {
            void sendWalletCreditEmail({
              name: walletUser.name,
              email: walletUser.email,
              userId: payment.customerId,
              amount: payment.amount ?? 0,
              balanceBefore,
              balanceAfter,
              reference,
            });
          }
        }
      } catch (walletErr: any) {
        console.error("[payments/verify] wallet credit failed:", walletErr?.message);
      }
    }

    // ─── Order payment flow ───────────────────────────────────────────
    if (newStatus === "SUCCESS" && order) {
      // Advance the order out of PLACED → CONFIRMED, since the vendor
      // can now safely accept it.
      if (order.status === "PLACED") {
        await db.order.update({
          where: { id: order.id },
          data: { status: "CONFIRMED" },
        });
      }

      // ─── Credit the vendor's PENDING balance ──────────────────────────
      // On payment success, the vendor gets credited the FULL item
      // subtotal (no commission deduction — commission was added on
      // top at checkout). The credit sits in PENDING until the order
      // is delivered, at which point it moves to AVAILABLE (withdrawable).
      //
      // We use the SUBTOTAL, not the order total — the service fee +
      // delivery fee are NOT the vendor's money:
      //   - serviceFee: Rush's commission, stays in Rush's Paystack balance
      //   - deliveryFee: pass-through to the rider (credited on delivery)
      if (order.vendorId && order.subtotal > 0) {
        try {
          await creditVendorPending({
            vendorId: order.vendorId,
            amount: order.subtotal,
            linkedOrderId: order.id,
            description: `Payment for order ${order.code}`,
          });
        } catch (e: any) {
          // Don't fail the payment verification if the vendor credit
          // fails — the customer has already paid. Log loudly so we
          // can reconcile manually.
          console.error(
            `[payments/verify] vendor credit failed for order ${order.id}:`,
            e?.message ?? e,
          );
        }
      }

      // Fire payment-success email (idempotent per reference).
      try {
        await sendPaymentNotification({
          userId: user.id,
          email: user.email,
          name: user.name,
          reference,
          status: "SUCCESS",
          amount: payment.amount,
          orderCode: order.code,
          type: "PAYMENT_SUCCESS",
        });
      } catch (emailErr) {
        console.error("[payments/verify] email failed:", emailErr);
      }
    } else if (newStatus === "FAILED" && order) {
      try {
        await sendPaymentNotification({
          userId: user.id,
          email: user.email,
          name: user.name,
          reference,
          status: "FAILED",
          amount: payment.amount,
          orderCode: order.code,
          type: "PAYMENT_FAILED",
        });
      } catch (emailErr) {
        console.error("[payments/verify] email failed:", emailErr);
      }
    }

    return NextResponse.json({
      status: newStatus,
      amount: payment.amount,
      orderId: payment.orderId,
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[payments/verify POST] error", err);
    return NextResponse.json(
      { error: err.message || "Failed to verify payment" },
      { status: 500 },
    );
  }
}
