import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getPaymentProvider, isPaystackConfigured } from "@/lib/payments/provider";
import { enforceRateLimit } from "@/lib/rate-limit";

/**
 * POST /api/payments/initiate
 *
 * Body (order payment):  { orderId: string }
 * Body (wallet top-up):  { amount: number, type: "wallet_topup" }
 *
 * Initiates a Paystack transaction. For order payments, loads the order
 * and charges order.total. For wallet top-ups, charges the specified
 * amount and marks the payment with type=wallet_topup so the webhook
 * knows to credit the wallet (not advance an order).
 *
 * When Paystack isn't configured, falls back to "mock payment" mode
 * that auto-succeeds — useful for development.
 */
export async function POST(req: NextRequest) {
  // Rate limit: 10 payment initiations per minute per IP.
  const blocked = enforceRateLimit(req, "pay-init", { limit: 10, windowMs: 60_000 });
  if (blocked) return blocked;

  try {
    const user = await requireUser();
    const body = await req.json();

    const isWalletTopup = body.type === "wallet_topup" && body.amount;

    // ─── Wallet top-up flow ──────────────────────────────────────────
    if (isWalletTopup) {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount < 100) {
        return NextResponse.json(
          { error: "Minimum wallet top-up is ₦100." },
          { status: 400 },
        );
      }

      const provider = getPaymentProvider();
      const isMock = provider.name === "mock";

      const init = await provider.initiate({
        email: user.email,
        amountNaira: amount,
        description: `Rush wallet top-up — ${user.name}`,
        metadata: {
          type: "wallet_topup",
          userId: user.id,
        },
      });

      // Record the Payment with type=wallet_topup so the webhook/verify
      // route knows to credit the wallet instead of advancing an order.
      await db.payment.upsert({
        where: { reference: init.reference },
        create: {
          reference: init.reference,
          orderId: null,
          customerId: user.id,
          amount,
          currency: "NGN",
          provider: provider.name,
          status: "INITIALIZED",
        },
        update: { status: "INITIALIZED" },
      });

      return NextResponse.json({
        reference: init.reference,
        authorizationUrl: init.authorizationUrl,
        provider: provider.name,
        isMock,
        paystackConfigured: isPaystackConfigured,
      });
    }

    // ─── Order payment flow (existing) ───────────────────────────────
    const { orderId } = body;

    if (!orderId) {
      return NextResponse.json({ error: "orderId is required" }, { status: 400 });
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: { vendor: true },
    });
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }
    if (order.customerId !== user.id) {
      return NextResponse.json(
        { error: "You don't own this order" },
        { status: 403 },
      );
    }
    if (order.status === "DELIVERED" || order.status === "CANCELLED") {
      return NextResponse.json(
        { error: `Order is ${order.status.toLowerCase()} — cannot pay.` },
        { status: 400 },
      );
    }

    const provider = getPaymentProvider();
    const isMock = provider.name === "mock";

    const init = await provider.initiate({
      orderId: order.id,
      email: user.email,
      amountNaira: order.total,
      description: `RUSH order ${order.code} — ${order.vendor.businessName}`,
      metadata: {
        orderCode: order.code,
        vendorName: order.vendor.businessName,
        items: order.items,
      },
    });

    await db.payment.upsert({
      where: { reference: init.reference },
      create: {
        reference: init.reference,
        orderId: order.id,
        customerId: user.id,
        amount: order.total,
        currency: "NGN",
        provider: provider.name,
        status: "INITIALIZED",
      },
      update: { status: "INITIALIZED" },
    });

    return NextResponse.json({
      reference: init.reference,
      authorizationUrl: init.authorizationUrl,
      provider: provider.name,
      isMock,
      paystackConfigured: isPaystackConfigured,
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[payments/initiate POST] error", err);
    return NextResponse.json(
      { error: err.message || "Failed to initiate payment" },
      { status: 500 },
    );
  }
}
