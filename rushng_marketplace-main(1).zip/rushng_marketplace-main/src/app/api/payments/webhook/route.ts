import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getPaymentProvider } from "@/lib/payments/provider";
import { creditVendorPending, refundVendorAvailableOnFailedPayout } from "@/lib/payments/vendor-wallet";
import { verifyTransfer } from "@/lib/payments/paystack";
import { notifyUser } from "@/lib/notify";
import { sendWithdrawalPaidEmail, sendWithdrawalFailedEmail } from "@/lib/email/wallet";
import { naira } from "@/lib/data";

/**
 * POST /api/payments/webhook
 *
 * Paystack webhook handler. Paystack fires this when a transaction
 * settles (success/failed) — even when the customer closed the tab
 * before our verify endpoint ran. It's the authoritative source of
 * truth for "did this payment actually go through".
 *
 * Verification:
 *   1. Verify the HMAC signature in the `x-paystack-signature` header
 *      against the raw request body.
 *   2. If the signature is valid, parse the JSON body and extract the
 *      Paystack event + reference.
 *   3. For "charge.success", look up the Payment by reference and
 *      mark it SUCCESS. (We don't trust the body alone — we also
 *      re-verify with Paystack's verify endpoint to defend against
 *      a forged-but-signed webhook.)
 *
 * Returns 200 always (Paystack retries on non-2xx).
 */
export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const signature = req.headers.get("x-paystack-signature");

    const provider = getPaymentProvider();
    const valid = await provider.verifyWebhookSignature(rawBody, signature);
    if (!valid) {
      // Don't 4xx — Paystack would retry forever. Just log and 200.
      console.warn("[payments/webhook] invalid signature — ignoring");
      return NextResponse.json({ ok: true, ignored: true });
    }

    const event = JSON.parse(rawBody);
    const eventType = event.event as string;

    // ─── Charge events (customer → Rush) ───────────────────────────────
    if (eventType === "charge.success") {
      return await _handleChargeSuccess(event, provider);
    }

    // ─── Transfer events (Rush → vendor) ───────────────────────────────
    if (eventType === "transfer.success" || eventType === "transfer.failed" || eventType === "transfer.reversed") {
      return await _handleTransferEvent(event, eventType);
    }

    // Other events we don't care about — ack and move on.
    return NextResponse.json({ ok: true, ignored: true });
  } catch (err: any) {
    console.error("[payments/webhook] error", err);
    // Still 200 — Paystack would otherwise retry.
    return NextResponse.json({ ok: true });
  }
}

/**
 * Handle `charge.success` — customer paid for an order.
 * Idempotent: if the Payment is already SUCCESS, no-op.
 * Credits the vendor's pending balance with the full item subtotal
 * (the idempotency check inside creditVendorPending prevents double-
 * crediting if the verify route already did this).
 */
async function _handleChargeSuccess(event: any, provider: ReturnType<typeof getPaymentProvider>) {
  const reference = event.data?.reference;
  if (!reference) {
    console.warn("[payments/webhook] charge.success missing reference");
    return NextResponse.json({ ok: true });
  }

  // Defense in depth: re-verify with Paystack's API.
  const verified = await provider.verify(reference);
  if (verified.status !== "success") {
    console.warn(`[payments/webhook] verify returned ${verified.status} for ${reference}`);
    return NextResponse.json({ ok: true });
  }

  const payment = await db.payment.findUnique({ where: { reference } });
  if (!payment) {
    console.warn(`[payments/webhook] unknown reference ${reference}`);
    return NextResponse.json({ ok: true });
  }

  // Amount re-check.
  if (payment.amount && verified.amountNaira > 0 && Math.abs(verified.amountNaira - payment.amount) > 1) {
    console.error(
      `[payments/webhook] amount mismatch for ${reference}: ` +
        `gateway=${verified.amountNaira} naira, payment=${payment.amount} naira`,
    );
    await db.payment.update({
      where: { reference },
      data: {
        status: "FAILED",
        providerResponse: JSON.stringify({
          ...verified,
          mismatchReason: `amount ${verified.amountNaira} ≠ payment.amount ${payment.amount}`,
        }),
      },
    });
    return NextResponse.json({ ok: true });
  }

  if (payment.status !== "SUCCESS") {
    await db.payment.update({
      where: { reference },
      data: { status: "SUCCESS", providerResponse: verified as any },
    });
  }

  if (payment.orderId) {
    const order = await db.order.findUnique({ where: { id: payment.orderId } });
    if (order && order.status === "PLACED") {
      await db.order.update({
        where: { id: order.id },
        data: { status: "CONFIRMED" },
      });

      // Credit the vendor's pending balance. Idempotent — if the verify
      // route already credited, this is a no-op.
      if (order.vendorId && order.subtotal > 0) {
        try {
          await creditVendorPending({
            vendorId: order.vendorId,
            amount: order.subtotal,
            linkedOrderId: order.id,
            description: `Payment for order ${order.code}`,
          });
        } catch (e: any) {
          console.error(
            `[payments/webhook] vendor credit failed for order ${order.id}:`,
            e?.message ?? e,
          );
        }
      }
    }
  }

  return NextResponse.json({ ok: true });
}

/**
 * Handle `transfer.success` / `transfer.failed` / `transfer.reversed` —
 * Paystack reporting the final status of a vendor payout.
 *
 * `transfer.success` → mark the Payout SUCCESS.
 * `transfer.failed`  → mark the Payout FAILED + refund the vendor's
 *                       available balance (the debit we did at withdraw
 *                       time is reversed).
 * `transfer.reversed`→ same as failed (Paystack reversed the transfer
 *                       after initially marking it pending — usually
 *                       invalid recipient).
 *
 * We re-verify with Paystack's `transfer/verify` API rather than
 * trusting the webhook body alone.
 */
async function _handleTransferEvent(event: any, eventType: string) {
  const transferCode = event.data?.transfer_code;
  if (!transferCode) {
    console.warn(`[payments/webhook] ${eventType} missing transfer_code`);
    return NextResponse.json({ ok: true });
  }

  // Look up the Payout by transferCode.
  const payout = await db.payout.findFirst({
    where: { transferCode },
  });
  if (!payout) {
    console.warn(`[payments/webhook] ${eventType} — unknown transfer ${transferCode}`);
    return NextResponse.json({ ok: true });
  }

  // Already terminal — no-op.
  if (payout.status === "SUCCESS" || payout.status === "FAILED") {
    return NextResponse.json({ ok: true });
  }

  // Defense in depth: re-verify with Paystack.
  let paystackStatus: string = eventType === "transfer.success" ? "success" : "failed";
  let failureReason: string | null | undefined = null;
  try {
    const verified = await verifyTransfer(transferCode);
    paystackStatus = verified.status;
    failureReason = verified.failureReason ?? null;
  } catch (e: any) {
    console.warn(
      `[payments/webhook] transfer verify failed (trusting webhook event): ${e?.message ?? e}`,
    );
  }

  if (paystackStatus === "success") {
    await db.payout.update({
      where: { id: payout.id },
      data: {
        status: "SUCCESS",
        paidAt: new Date(),
        providerResponse: JSON.stringify({ event, verified: paystackStatus }),
      },
    });
    console.log(`[payments/webhook] payout ${payout.id} SUCCESS (₦${payout.amount})`);

    // ─── Customer withdrawal: notify + email ─────────────────────────
    if (!payout.vendorId && payout.userId) {
      void notifyUser({
        userId: payout.userId,
        type: "PAYOUT",
        title: `Withdrawal completed — ₦${payout.amount.toLocaleString()}`,
        body: `${naira(payout.amount)} has been sent to ${payout.bankName || "your bank"}.`,
      });
      const user = await db.user.findUnique({
        where: { id: payout.userId },
        select: { name: true, email: true },
      });
      if (user) {
        void sendWithdrawalPaidEmail({
          name: user.name,
          email: user.email,
          userId: payout.userId,
          amount: payout.amount,
          balanceBefore: 0, // wallet was already debited at withdraw time
          balanceAfter: 0,
          reference: payout.reference || undefined,
          bankName: payout.bankName || undefined,
        });
      }
    }
  } else {
    // FAILED or REVERSED — refund the balance.
    await db.payout.update({
      where: { id: payout.id },
      data: {
        status: "FAILED",
        failureReason: failureReason || `Paystack reported ${eventType}`,
        providerResponse: JSON.stringify({ event, verified: paystackStatus }),
      },
    });
    try {
      // Check if this is a customer wallet withdrawal (vendorId=null,
      // userId set) or a vendor payout (vendorId set).
      if (payout.vendorId) {
        // Vendor payout — refund the vendor's available balance.
        await refundVendorAvailableOnFailedPayout({
          vendorId: payout.vendorId,
          amount: payout.amount,
          payoutId: payout.id,
        });
        console.log(
          `[payments/webhook] payout ${payout.id} FAILED — refunded ₦${payout.amount} to vendor ${payout.vendorId}`,
        );
      } else if (payout.userId) {
        // Customer wallet withdrawal — refund the customer's wallet.
        const wallet = await db.wallet.findUnique({
          where: { userId: payout.userId },
        });
        if (wallet) {
          const walletBefore = wallet.balance ?? 0;
          await db.wallet.updateMany({
            where: { id: wallet.id },
            data: { balance: { increment: payout.amount } },
          });
          try {
            const { randomBytes } = await import("node:crypto");
            await db.walletLedgerEntry.create({
              data: {
                id: randomBytes(12).toString("hex"),
                walletId: wallet.id,
                type: "CREDIT",
                amount: payout.amount,
                balanceBefore: walletBefore,
                balanceAfter: walletBefore + payout.amount,
                description: `Refund — withdrawal ${payout.id} failed at Paystack`,
                createdAt: new Date(),
              },
            });
          } catch (_) {}
          console.log(
            `[payments/webhook] payout ${payout.id} FAILED — refunded ₦${payout.amount} to customer wallet ${payout.userId}`,
          );

          // ─── Customer withdrawal: notify + email (refund) ──────────
          void notifyUser({
            userId: payout.userId,
            type: "PAYOUT",
            title: `Withdrawal failed — ₦${payout.amount.toLocaleString()} refunded`,
            body: `The transfer to ${payout.bankName || "your bank"} failed. Your wallet has been refunded.`,
          });
          const user = await db.user.findUnique({
            where: { id: payout.userId },
            select: { name: true, email: true },
          });
          if (user) {
            void sendWithdrawalFailedEmail({
              name: user.name,
              email: user.email,
              userId: payout.userId,
              amount: payout.amount,
              balanceBefore: walletBefore,
              balanceAfter: walletBefore + payout.amount,
              reference: payout.reference || undefined,
              bankName: payout.bankName || undefined,
              description: failureReason || undefined,
            });
          }
        }
      }
    } catch (e: any) {
      console.error(
        `[payments/webhook] refund failed for payout ${payout.id}:`,
        e?.message ?? e,
      );
    }
  }

  return NextResponse.json({ ok: true });
}
