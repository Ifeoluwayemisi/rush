import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";

/**
 * GET /api/saved-items?type=vendors|products|providers
 *
 * Returns the user's saved items (follows). The existing `follows`
 * collection already stores (userId, targetType, targetId) tuples —
 * we reuse it rather than adding a new model.
 *
 * Without a `type` param, returns all saved items grouped by type.
 */
export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const type = req.nextUrl.searchParams.get("type"); // "vendor" | "product" | "provider"

    const where: Record<string, unknown> = { userId: user.id };
    if (type) where.targetType = type;

    const follows = await db.follow.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });

    // If filtering by type, hydrate the target objects.
    if (type === "vendor") {
      const ids = follows.map((f) => f.targetId);
      const vendors = ids.length
        ? await db.vendorProfile.findMany({ where: { id: { in: ids } } })
        : [];
      const vMap = new Map(vendors.map((v) => [v.id, v]));
      return NextResponse.json({
        items: follows.map((f) => ({
          id: f.id,
          targetType: f.targetType,
          targetId: f.targetId,
          createdAt: f.createdAt instanceof Date ? f.createdAt.toISOString() : f.createdAt,
          target: vMap.get(f.targetId)
            ? {
                id: vMap.get(f.targetId)!.id,
                businessName: vMap.get(f.targetId)!.businessName,
                slug: vMap.get(f.targetId)!.slug,
                logo: vMap.get(f.targetId)!.logo,
                category: vMap.get(f.targetId)!.category,
                location: vMap.get(f.targetId)!.location,
              }
            : null,
        })),
      });
    }

    if (type === "product") {
      const ids = follows.map((f) => f.targetId);
      const products = ids.length
        ? await db.product.findMany({ where: { id: { in: ids } } })
        : [];
      const pMap = new Map(products.map((p) => [p.id, p]));
      return NextResponse.json({
        items: follows.map((f) => ({
          id: f.id,
          targetType: f.targetType,
          targetId: f.targetId,
          createdAt: f.createdAt instanceof Date ? f.createdAt.toISOString() : f.createdAt,
          target: pMap.get(f.targetId)
            ? {
                id: pMap.get(f.targetId)!.id,
                name: pMap.get(f.targetId)!.name,
                price: pMap.get(f.targetId)!.price,
                images: pMap.get(f.targetId)!.images,
                category: pMap.get(f.targetId)!.category,
              }
            : null,
        })),
      });
    }

    if (type === "provider") {
      const ids = follows.map((f) => f.targetId);
      const providers = ids.length
        ? await db.provider.findMany({ where: { id: { in: ids } } })
        : [];
      const pMap = new Map(providers.map((p) => [p.id, p]));
      return NextResponse.json({
        items: follows.map((f) => ({
          id: f.id,
          targetType: f.targetType,
          targetId: f.targetId,
          createdAt: f.createdAt instanceof Date ? f.createdAt.toISOString() : f.createdAt,
          target: pMap.get(f.targetId)
            ? {
                id: pMap.get(f.targetId)!.id,
                businessName: pMap.get(f.targetId)!.businessName,
                slug: pMap.get(f.targetId)!.slug,
                avatar: pMap.get(f.targetId)!.avatar,
                category: pMap.get(f.targetId)!.category,
                location: pMap.get(f.targetId)!.location,
              }
            : null,
        })),
      });
    }

    // No type filter — return all, un-hydrated (the client can fetch
    // per-type if needed).
    return NextResponse.json({
      items: follows.map((f) => ({
        id: f.id,
        targetType: f.targetType,
        targetId: f.targetId,
        createdAt: f.createdAt instanceof Date ? f.createdAt.toISOString() : f.createdAt,
      })),
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[saved-items GET] error", err);
    return NextResponse.json({ error: "Failed to load saved items" }, { status: 500 });
  }
}

/**
 * POST /api/saved-items
 *
 * Body: { targetType: "vendor" | "product" | "provider", targetId: string }
 *
 * Save (follow) an item. Idempotent — if already saved, returns 200.
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { targetType, targetId } = body;

    if (!targetType || !targetId) {
      return NextResponse.json({ error: "targetType and targetId are required" }, { status: 400 });
    }
    if (!["vendor", "product", "provider"].includes(targetType)) {
      return NextResponse.json({ error: "Invalid targetType" }, { status: 400 });
    }

    // Check if already saved.
    const existing = await db.follow.findFirst({
      where: { userId: user.id, targetType, targetId },
    });
    if (existing) {
      return NextResponse.json({ ok: true, alreadySaved: true });
    }

    await db.follow.create({
      data: {
        userId: user.id,
        targetType,
        targetId,
      },
    });

    return NextResponse.json({ ok: true, saved: true });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[saved-items POST] error", err);
    return NextResponse.json({ error: "Failed to save item" }, { status: 500 });
  }
}

/**
 * DELETE /api/saved-items?id=<followId>
 *
 * Remove a saved item (unfollow).
 */
export async function DELETE(req: NextRequest) {
  try {
    const user = await requireUser();
    const id = req.nextUrl.searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "id is required" }, { status: 400 });
    }

    // Ensure the follow belongs to the caller.
    const follow = await db.follow.findUnique({ where: { id } });
    if (!follow || follow.userId !== user.id) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    await db.follow.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[saved-items DELETE] error", err);
    return NextResponse.json({ error: "Failed to remove item" }, { status: 500 });
  }
}
