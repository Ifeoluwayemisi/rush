import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { enforceRateLimit } from "@/lib/rate-limit";
import {
  PinError,
  pinErrorResponse,
  sanitizePin,
  compareTransactionPin,
  PIN_LENGTH,
  PIN_MAX_ATTEMPTS,
} from "@/lib/txn-pin";

/**
 * POST /api/auth/verify-pin
 *
 * Body: { pin: string }
 *
 * Standalone PIN check used by the client as a pre-flight (e.g. to
 * decide whether to show a reminder). Money-moving routes
 * (withdraw, payout, wallet debit) verify the PIN server-side
 * themselves — calling this endpoint alone never authorizes
 * anything.
 *
 * Security:
 * - Rate limited (10/min per IP).
 * - Respects the account-level lockout (5 wrong attempts → temp
 *   lock) and consumes/contributes attempts exactly like the
 *   guarded routes, so it can't be used as an oracle bypass.
 * - Never reveals whether a PIN exists beyond a boolean hint.
 */
export async function POST(req: NextRequest) {
  const blocked = enforceRateLimit(req, "auth-verify-pin", { limit: 10, windowMs: 60_000 });
  if (blocked) return blocked;

  try {
    const user = await requireUser();
    const body = await req.json();
    const sanitized = sanitizePin(body?.pin);

    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { transactionPin: true, pinLockedUntil: true },
    });

    if (!fresh?.transactionPin) {
      return NextResponse.json(
        {
          valid: false,
          hasPin: false,
          error: "No transaction PIN set. Please set one to continue.",
          code: "PIN_SETUP_REQUIRED",
        },
        { status: 400 },
      );
    }

    // Respect an active lockout — refuse even the correct PIN.
    if (fresh.pinLockedUntil && new Date(fresh.pinLockedUntil).getTime() > Date.now()) {
      const retryAfterSeconds = Math.ceil(
        (new Date(fresh.pinLockedUntil).getTime() - Date.now()) / 1000,
      );
      return NextResponse.json(
        {
          valid: false,
          hasPin: true,
          error: `PIN temporarily locked. Try again in ${Math.max(1, Math.ceil(retryAfterSeconds / 60))} minute(s).`,
          code: "PIN_LOCKED",
          retryAfterSeconds,
        },
        { status: 429 },
      );
    }

    if (sanitized.length !== PIN_LENGTH) {
      return NextResponse.json(
        { valid: false, hasPin: true, error: `PIN must be ${PIN_LENGTH} digits.` },
        { status: 400 },
      );
    }

    const valid = await compareTransactionPin(sanitized, fresh.transactionPin);

    if (!valid) {
      // Track the failed attempt through the same counter the guarded
      // routes use, so this endpoint can't be used to brute-force
      // without consequences.
      const row = await db.user.findUnique({
        where: { id: user.id },
        select: { pinFailedAttempts: true },
      });
      const attempts = (row?.pinFailedAttempts ?? 0) + 1;
      await db.user.updateMany({
        where: { id: user.id },
        data: { pinFailedAttempts: { increment: 1 } },
      });
      const remaining = Math.max(0, PIN_MAX_ATTEMPTS - attempts);

      return NextResponse.json(
        {
          valid: false,
          hasPin: true,
          error: remaining
            ? `Incorrect PIN. ${remaining} attempt(s) remaining.`
            : "Incorrect PIN. Your PIN is now locked — try again in 15 minutes.",
          code: "PIN_INVALID",
          attemptsRemaining: remaining,
        },
        { status: 403 },
      );
    }

    // Success — clear the failure counter.
    await db.user
      .updateMany({ where: { id: user.id }, data: { pinFailedAttempts: 0 } })
      .catch(() => {});

    return NextResponse.json({ valid: true, hasPin: true });
  } catch (err: any) {
    if (err instanceof PinError) return pinErrorResponse(err);
    if (err instanceof Response) return err;
    console.error("[auth/verify-pin POST] error", err);
    return NextResponse.json({ error: "Failed to verify PIN." }, { status: 500 });
  }
}
