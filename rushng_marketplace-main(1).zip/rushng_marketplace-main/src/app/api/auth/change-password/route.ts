import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser, verifyPassword, hashPassword } from "@/lib/auth";

/**
 * POST /api/auth/change-password
 *
 * Body: { oldPassword, newPassword }
 *
 * Verifies the old password, then hashes and saves the new one.
 * Only works for email/password accounts — Firebase OAuth accounts
 * have no password to change (they manage it via Google).
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    const body = await req.json();
    const { oldPassword, newPassword } = body;

    if (!oldPassword || !newPassword) {
      return NextResponse.json({ error: "Both old and new passwords are required" }, { status: 400 });
    }
    if (newPassword.length < 6) {
      return NextResponse.json({ error: "New password must be at least 6 characters" }, { status: 400 });
    }

    // Fetch the user's current password hash.
    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { passwordHash: true, firebaseUid: true },
    });

    if (!fresh) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // If the user has a firebaseUid and no passwordHash, they signed up
    // via Google — they can't change a password they don't have.
    if (!fresh.passwordHash) {
      return NextResponse.json({
        error: "Your account uses Google Sign-In — no password to change. Manage your Google password at myaccount.google.com.",
      }, { status: 400 });
    }

    // Verify the old password.
    const valid = await verifyPassword(oldPassword, fresh.passwordHash);
    if (!valid) {
      return NextResponse.json({ error: "Current password is incorrect" }, { status: 403 });
    }

    // Hash + save the new password.
    const newHash = await hashPassword(newPassword);
    await db.user.update({
      where: { id: user.id },
      data: { passwordHash: newHash },
    });

    return NextResponse.json({ ok: true, message: "Password changed successfully" });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[auth/change-password POST] error", err);
    return NextResponse.json({ error: "Failed to change password" }, { status: 500 });
  }
}
