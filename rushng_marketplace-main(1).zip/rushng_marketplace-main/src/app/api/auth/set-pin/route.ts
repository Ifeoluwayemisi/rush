import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser, verifyPassword } from "@/lib/auth";
import { enforceRateLimit } from "@/lib/rate-limit";
import { notifyUser } from "@/lib/notify";
import {
  PinError,
  pinErrorResponse,
  validateNewPin,
  hashTransactionPin,
  requirePinVerified,
} from "@/lib/txn-pin";

/**
 * POST /api/auth/set-pin
 *
 * Body:
 *   - First time:  { pin }                       (no PIN set yet)
 *   - Changing:    { pin, currentPin }           — or —
 *                  { pin, password }             (forgot-PIN path)
 *
 * Sets or updates the user's 4-digit transaction PIN.
 *
 * ─── Best practices enforced here ─────────────────────────────────
 * - Changing an existing PIN requires re-authentication (current PIN
 *   verified through the same lockout/attempt tracking as payments,
 *   OR the account password). A stolen session alone cannot take
 *   over payouts.
 * - Weak PINs (repeats, runs, top-common codes like 1234/0000) are
 *   rejected server-side.
 * - PIN is hashed with per-user-salted bcrypt — never plaintext,
 *   never a deterministic global-key hash.
 * - Rate limited to 5 attempts/min per IP.
 * - Successful change resets lockout counters and notifies the user.
 *
 * The PIN guards money leaving the wallet: withdrawals, vendor
 * payouts and wallet payments at checkout. It is NOT required for
 * card top-ups (the bank authorizes those via 3DS) or cash on
 * delivery.
 */
export async function POST(req: NextRequest) {
  const blocked = enforceRateLimit(req, "auth-set-pin", { limit: 5, windowMs: 60_000 });
  if (blocked) return blocked;

  try {
    const user = await requireUser();
    const body = await req.json();
    const { pin, currentPin, password } = body;

    // ─── Load current PIN state ──────────────────────────────────────
    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { transactionPin: true },
    });
    const hasPin = !!fresh?.transactionPin;

    // ─── Re-authentication gate when changing ────────────────────────
    if (hasPin) {
      const providedPin = typeof currentPin === "string" && currentPin.length > 0;
      const providedPassword = typeof password === "string" && password.length > 0;
      if (!providedPin && !providedPassword) {
        return NextResponse.json(
          {
            error:
              "Enter your current PIN (or account password) to change your transaction PIN.",
            code: "CURRENT_PIN_REQUIRED",
          },
          { status: 403 },
        );
      }
      if (providedPin) {
        // Same lockout + attempt tracking as real transactions.
        try {
          await requirePinVerified(user.id, currentPin);
        } catch (err) {
          if (err instanceof PinError) return pinErrorResponse(err);
          throw err;
        }
      } else {
        // Forgot-PIN path — account password re-authentication.
        const pwRow = await db.user.findUnique({
          where: { id: user.id },
          select: { password: true },
        });
        const ok = pwRow?.password
          ? await verifyPassword(String(password), pwRow.password)
          : false;
        if (!ok) {
          return NextResponse.json(
            { error: "Incorrect account password.", code: "PASSWORD_INVALID" },
            { status: 403 },
          );
        }
      }
    }

    // ─── Validate + hash the new PIN ─────────────────────────────────
    const weakReason = validateNewPin(pin);
    if (weakReason) {
      return NextResponse.json(
        { error: weakReason, code: "PIN_WEAK" },
        { status: 400 },
      );
    }
    const hashedPin = await hashTransactionPin(String(pin));

    await db.user.update({
      where: { id: user.id },
      data: {
        transactionPin: hashedPin,
        pinSetAt: new Date(),
        // Fresh start: clear any lockout state from the old PIN.
        pinFailedAttempts: 0,
        pinLockedUntil: null,
        pinLockCount: 0,
      },
    });

    void notifyUser({
      userId: user.id,
      type: "SYSTEM",
      title: hasPin ? "Transaction PIN changed" : "Transaction PIN created",
      body: hasPin
        ? "Your transaction PIN was just changed. If this wasn't you, change your password and contact support immediately."
        : "Your 4-digit transaction PIN is now active. You'll use it for withdrawals and wallet payments.",
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      message: hasPin
        ? "Transaction PIN updated successfully."
        : "Transaction PIN set successfully.",
    });
  } catch (err: any) {
    if (err instanceof Response) return err;
    console.error("[auth/set-pin POST] error", err);
    return NextResponse.json({ error: "Failed to set PIN." }, { status: 500 });
  }
}
