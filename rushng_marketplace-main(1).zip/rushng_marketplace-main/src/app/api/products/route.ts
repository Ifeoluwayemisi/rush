import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { checkCapability, suspendedMessage, pendingVerificationMessage } from "@/lib/capability";
import { safeJsonParse } from "@/lib/safe-json";
import { isFullyVerified, UNVERIFIED_PRODUCT_CAP } from "@/lib/kyc";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const query = url.searchParams.get("q");
    const vendorId = url.searchParams.get("vendorId");

    // 1. Check if caller is authenticated
    let currentUser: { id: string } | null = null;
    try {
      currentUser = await requireUser();
    } catch {
      currentUser = null;
    }

    // 2. Check if the authenticated user owns this specific vendor
    let isSpecificOwner = false;
    if (vendorId && currentUser) {
      const vendorCheck = await db.vendorProfile.findUnique({
        where: { id: vendorId },
        select: { userId: true },
      });
      if (vendorCheck && vendorCheck.userId === currentUser.id) {
        isSpecificOwner = true;
      }
    }

    // 3. Find IDs of all public vendors to avoid invalid relation operators
    let allowedVendorIds: string[] | undefined = undefined;
    if (!isSpecificOwner) {
      const publicVendors = await db.vendorProfile.findMany({
        where: { visibility: "PUBLIC" },
        select: { id: true },
      });
      allowedVendorIds = publicVendors.map((v) => v.id);
    }

    // 4. Query products using vendorId instead of nested vendor object
    const products = await db.product.findMany({
      where: {
        ...(category && category !== "All" ? { category } : {}),
        ...(vendorId
          ? { vendorId }
          : allowedVendorIds
          ? { vendorId: { in: allowedVendorIds } }
          : {}),
        ...(query ? { name: { contains: query, mode: "insensitive" } } : {}),
      },
      include: {
        vendor: {
          select: {
            id: true,
            businessName: true,
            slug: true,
            location: true,
            visibility: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    const transformed = products.map((p) => ({
      id: p.id,
      vendorId: p.vendorId,
      vendorName: p.vendor?.businessName ?? "Unknown Store",
      vendorSlug: p.vendor?.slug ?? "",
      name: p.name,
      description: p.description,
      price: p.price,
      compareAtPrice: p.compareAtPrice ?? undefined,
      images: safeJsonParse<string[]>(p.images, []),
      category: p.category,
      condition: p.condition ?? undefined,
      stock: p.stock,
      rating: p.rating,
      reviewCount: p.reviewCount,
      location: p.location,
      createdAt: p.createdAt.toISOString(),
      tags: safeJsonParse<string[]>(p.tags, []),
    }));

    return NextResponse.json({ products: transformed });
  } catch (err: any) {
    console.error("[products GET] error", err?.message ?? err);
    return NextResponse.json(
      { error: "Failed to load products", details: err?.message },
      { status: 500 },
    );
  }
}

// POST /api/products — vendor creates a product under their own store.
// The vendorId always comes from the caller's own vendor profile, never
// from the request body, so one vendor can never create products on
// behalf of another.
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    // Note: we deliberately do NOT require email verification here.
    // Users can create stores and list products immediately —
    // verification (KYC) is an upgrade, not a gate.

    const vendorProfile = (user as any).vendorProfile;
    if (!vendorProfile) {
      return NextResponse.json(
        { error: "You need a vendor store before you can add products." },
        { status: 403 },
      );
    }

    // Capability-status enforcement.
    const vendorCap = checkCapability(user, "VENDOR");
    if (!vendorCap.hasCapability) {
      return NextResponse.json(
        { error: "You need a vendor store before you can add products." },
        { status: 403 },
      );
    }
    if (vendorCap.status === "SUSPENDED") {
      return NextResponse.json({ error: suspendedMessage("VENDOR") }, { status: 403 });
    }
    if (vendorCap.status === "PENDING_VERIFICATION") {
      return NextResponse.json({ error: pendingVerificationMessage("VENDOR") }, { status: 403 });
    }

    // ─── Unverified vendor listing cap ────────────────────────────────
    // Vendors who haven't completed KYC are soft-capped at
    // UNVERIFIED_PRODUCT_CAP active products. This nudges them toward
    // verification without blocking exploration of the platform. We
    // re-fetch the vendor profile here (rather than relying on the
    // include from getCurrentUser) because the KYC fields may have
    // been updated since the session cookie was issued.
    if (!isFullyVerified(vendorProfile)) {
      const freshVendor = await db.vendorProfile.findUnique({
        where: { id: vendorProfile.id },
        select: { verificationTier: true, kycStatus: true, verified: true },
      });
      if (!isFullyVerified(freshVendor ?? vendorProfile)) {
        const activeProductCount = await db.product.count({
          where: { vendorId: vendorProfile.id },
        });
        if (activeProductCount >= UNVERIFIED_PRODUCT_CAP) {
          return NextResponse.json(
            {
              error:
                `You've reached the ${UNVERIFIED_PRODUCT_CAP}-product limit for unverified vendors. ` +
                `Complete KYC verification to unlock unlimited listings.`,
              code: "UNVERIFIED_PRODUCT_CAP",
              cap: UNVERIFIED_PRODUCT_CAP,
            },
            { status: 403 },
          );
        }
      }
    }

    const body = await req.json();
    const { name, description, price, compareAtPrice, images, category, condition, stock, location, tags } = body;

    if (!name || !description || price === undefined || price === null || !category) {
      return NextResponse.json(
        { error: "Name, description, price, and category are required." },
        { status: 400 },
      );
    }
    const parsedPrice = Number(price);
    if (!Number.isFinite(parsedPrice) || parsedPrice < 0) {
      return NextResponse.json({ error: "Price must be a valid non-negative number." }, { status: 400 });
    }
    const imageList: string[] = Array.isArray(images) ? images.filter(Boolean) : [];
    if (imageList.length === 0) {
      return NextResponse.json({ error: "Add at least one product photo." }, { status: 400 });
    }

    for (const url of imageList) {
      if (typeof url !== "string" || (!url.startsWith("/api/uploads/") && !url.startsWith("/uploads/") && !url.startsWith("https://"))) {
        return NextResponse.json(
          { error: "Image URLs must be /api/uploads/ paths or https:// URLs." },
          { status: 400 },
        );
      }
    }

    const product = await db.product.create({
      data: {
        vendorId: vendorProfile.id,
        name,
        description,
        price: parsedPrice,
        compareAtPrice: compareAtPrice !== undefined && compareAtPrice !== null && compareAtPrice !== ""
          ? Number(compareAtPrice)
          : null,
        images: JSON.stringify(imageList),
        category,
        condition: condition || null,
        stock: stock !== undefined && stock !== null && stock !== "" ? Math.max(0, parseInt(stock, 10) || 0) : 1,
        location: location || vendorProfile.location,
        tags: JSON.stringify(Array.isArray(tags) ? tags : []),
      },
    });

    return NextResponse.json({
      product: {
        ...product,
        images: JSON.parse(product.images),
        tags: JSON.parse(product.tags),
        vendorName: vendorProfile.businessName,
        vendorSlug: vendorProfile.slug,
      },
    });
  } catch (err: any) {
    if (err instanceof Response) throw err;
    console.error("[products POST] error", err);
    return NextResponse.json({ error: err.message || "Failed to create product" }, { status: 500 });
  }
}
