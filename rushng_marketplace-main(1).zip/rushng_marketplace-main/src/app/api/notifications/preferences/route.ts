import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";

/**
 * GET /api/notifications/preferences — returns the user's notification preferences.
 * PATCH /api/notifications/preferences — updates the preferences.
 *
 * Stored as JSON on user.notificationPrefs (schemaless MongoDB).
 */

export async function GET() {
  try {
    const user = await requireUser();
    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { notificationPrefs: true },
    });
    let prefs: any = {};
    if (fresh?.notificationPrefs) {
      try { prefs = JSON.parse(fresh.notificationPrefs as string); } catch {}
    }
    return NextResponse.json({ preferences: prefs });
  } catch (err: any) {
    if (err instanceof Response) return err;
    return NextResponse.json({ error: "Failed to load preferences" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json();

    // Merge with existing prefs so partial updates work.
    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { notificationPrefs: true },
    });
    let existing: any = {};
    if (fresh?.notificationPrefs) {
      try { existing = JSON.parse(fresh.notificationPrefs as string); } catch {}
    }
    const merged = { ...existing, ...body };

    await db.user.update({
      where: { id: user.id },
      data: { notificationPrefs: JSON.stringify(merged) },
    });

    return NextResponse.json({ ok: true, preferences: merged });
  } catch (err: any) {
    if (err instanceof Response) return err;
    return NextResponse.json({ error: "Failed to update preferences" }, { status: 500 });
  }
}
