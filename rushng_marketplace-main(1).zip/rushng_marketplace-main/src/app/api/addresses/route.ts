import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { randomBytes } from "node:crypto";

/**
 * GET /api/addresses — list the user's saved addresses.
 * POST /api/addresses — { label, address } → save a new address.
 * DELETE /api/addresses?id=<id> — remove an address.
 *
 * Stored as JSON array on user.addresses field (schemaless MongoDB).
 */

export async function GET() {
  try {
    const user = await requireUser();
    const fresh = await db.user.findUnique({
      where: { id: user.id },
      select: { addresses: true },
    });
    let addresses: any[] = [];
    if (fresh?.addresses) {
      try { addresses = JSON.parse(fresh.addresses as string); } catch { addresses = []; }
    }
    return NextResponse.json({ addresses });
  } catch (err: any) {
    if (err instanceof Response) return err;
    return NextResponse.json({ error: "Failed to load addresses" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { label, address } = body;

    if (!label || !address || address.trim().length < 5) {
      return NextResponse.json({ error: "Label and address are required" }, { status: 400 });
    }

    const fresh = await db.user.findUnique({ where: { id: user.id }, select: { addresses: true } });
    let addresses: any[] = [];
    if (fresh?.addresses) {
      try { addresses = JSON.parse(fresh.addresses as string); } catch {}
    }

    const newAddr = { id: randomBytes(8).toString("hex"), label, address: address.trim() };
    addresses.push(newAddr);

    await db.user.update({
      where: { id: user.id },
      data: { addresses: JSON.stringify(addresses) },
    });

    return NextResponse.json({ ok: true, address: newAddr });
  } catch (err: any) {
    if (err instanceof Response) return err;
    return NextResponse.json({ error: "Failed to save address" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireUser();
    const id = req.nextUrl.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const fresh = await db.user.findUnique({ where: { id: user.id }, select: { addresses: true } });
    let addresses: any[] = [];
    if (fresh?.addresses) {
      try { addresses = JSON.parse(fresh.addresses as string); } catch {}
    }

    addresses = addresses.filter((a) => a.id !== id);
    await db.user.update({
      where: { id: user.id },
      data: { addresses: JSON.stringify(addresses) },
    });

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    if (err instanceof Response) return err;
    return NextResponse.json({ error: "Failed to remove address" }, { status: 500 });
  }
}
